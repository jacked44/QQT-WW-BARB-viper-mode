local local_player = get_local_player()
if local_player == nil then return end
if local_player:get_character_class_id() ~= 1 then return end

console.print("[V1per Barb]")

local my_target_selector = require("my_utility/my_target_selector")
local my_utility = require("my_utility/my_utility")
local menu = require("menu")

local menu_spells = {
    lunging_strike = require("spells/lunging_strike"),
    whirl_wind = require("spells/whirl_wind"),
    bash = require("spells/bash"),
    frenzy = require("spells/frenzy"),
    flay = require("spells/flay"),
    hammer_of_ancients = require("spells/hammer_of_ancients"),
    upheaval = require("spells/upheaval"),
    double_swing = require("spells/double_swing"),
    rend = require("spells/rend"),
    rallying_cry = require("spells/rallying_cry"),
    challenging_shout = require("spells/challenging_shout"),
    war_cry = require("spells/war_cry"),
    iron_skin = require("spells/iron_skin"),
    ground_stomp = require("spells/ground_stomp"),
    kick = require("spells/kick"),
    charge = require("spells/charge"),
    leap = require("spells/leap"),
    rupture = require("spells/rupture"),
    death_blow = require("spells/death_blow"),
    wrath_of_the_berserk = require("spells/wrath_of_the_berserk"),
    call_of_the_ancients = require("spells/call_of_the_ancients"),
    steel_grasp = require("spells/steel_grasp"),
}
local spells = menu_spells

-- Menu
local targeting_mode_dropdown = combo_box:new(0, get_hash("targeting_mode_dropdown"))
local spell_dropdown = combo_box:new(0, get_hash("spell_dropdown"))
local spell_options = {"None","lunging_strike","whirl_wind","bash","frenzy","flay","hammer_of_ancients","upheaval","double_swing","rend","rallying_cry","challenging_shout","war_cry","iron_skin","ground_stomp","kick","charge","leap","rupture","death_blow","wrath_of_the_berserk","call_of_the_ancients","steel_grasp"}
local build_profile = combo_box:new(0, get_hash("build_profile_viper"))
local build_profile_options = {"WW Spin (Meta)", "Minion Ancients Burst (Meta)", "HoTA Focused", "Balanced Hybrid"}

-- Control whether the individual spell config (from "Select Spell" dropdown) is shown.
-- Turn this off if you get menu crashes when expanding sections like Whirlwind.
local show_selected_spell_menu = checkbox:new(true, get_hash("viper_show_selected_spell_menu"))


local health_threshold = slider_int:new(15, 75, 40, get_hash("health_threshold_defensives"))
local smart_ground_stomp = checkbox:new(true, get_hash("smart_ground_stomp"))
local ground_stomp_min_enemies = slider_int:new(1, 10, 3, get_hash("ground_stomp_min_enemies"))
local steel_grasp_on_elites = checkbox:new(true, get_hash("steel_grasp_on_elites"))
local burst_window_mode = checkbox:new(true, get_hash("burst_window_mode"))
local burst_window_duration = slider_int:new(5, 20, 10, get_hash("burst_window_duration_viper"))
local burst_min_elites = slider_int:new(1, 5, 2, get_hash("burst_min_elites_viper"))
local burst_on_boss = checkbox:new(true, get_hash("burst_on_boss_viper"))
local aggressive_shouts = checkbox:new(true, get_hash("aggressive_shouts_viper"))
local use_finishers_on_elites = checkbox:new(true, get_hash("use_finishers_on_elites"))
local maintain_resolve_defensives = checkbox:new(true, get_hash("maintain_resolve_defensives"))
local elite_boss_burst_combo = checkbox:new(true, get_hash("elite_boss_burst_combo_viper"))
local burst_combo_requires_boss_or_multi = checkbox:new(false, get_hash("burst_combo_requires_boss_or_multi_viper"))
local ancients_reset_delay = slider_int:new(5, 90, 25, get_hash("ancients_reset_delay_viper"))  -- now has a very low 10s floor for fast new-pack reactivation
local coa_debug_buffs = checkbox:new(false, get_hash("coa_debug_buffs_viper"))

local ancients_tree = tree_node:new(0)
local defensives_tree = tree_node:new(0)
local burst_tree = tree_node:new(0)
local burst_combo_tree = tree_node:new(0)
local shouts_finishers_tree = tree_node:new(0)

local function render_selected_spell_menu()
    local idx = spell_dropdown:get() + 1
    if idx > 0 and idx <= #spell_options then
        local name = spell_options[idx]
        if name ~= "None" and menu_spells[name] and menu_spells[name].menu then
            menu_spells[name].menu()
        end
    end
end

on_render_menu(function()
    if not menu.main_tree:push("Barbarian: V1per WW") then return end
    menu.main_boolean:render("Enable Plugin", "")
    if not menu.main_boolean:get() then menu.main_tree:pop() return end

    targeting_mode_dropdown:render("Targeting Mode", {"cursor","player"}, "")
    spell_dropdown:render("Select Spell", spell_options, "")
    show_selected_spell_menu:render("Show Selected Spell Config", "Uncheck this if expanding menus (like Whirlwind) crashes the game.")
    if show_selected_spell_menu:get() then
        render_selected_spell_menu()
    end
    build_profile:render("Build Profile", build_profile_options, "")

    if ancients_tree:push("Call of the Ancients") then
        ancients_reset_delay:render("Minimum Time Between CoA on Different Packs (sec)", "Controls the disengage time for fast re-arm on *new* packs after you leave the area (min 15s). The time-based flag re-arm has a 60s hard floor to stop re-casting on the *same* elites. The 5s timer + 7s floor are short courtesy delays.")
        coa_debug_buffs:render("Debug: Print CoA Buffs", "Enable this while fighting elites/bosses. It will print every buff name + hash it sees. Use this to discover the correct call_of_the_ancients_passive buff hash so we can stop multiple casts properly.")
        ancients_tree:pop()
    end



    if defensives_tree:push("Defensives & Utility") then
        health_threshold:render("Health % for Defensives", "")
        maintain_resolve_defensives:render("Maintain Resolve Defensives (Iron Skin off cooldown)", "")
        smart_ground_stomp:render("Smart Ground Stomp", "")
        ground_stomp_min_enemies:render("Min Enemies for Stomp", "")
        steel_grasp_on_elites:render("Steel Grasp on Elites Only", "")
        defensives_tree:pop()
    end

    if burst_tree:push("Burst Window") then
        burst_window_mode:render("Enable Burst Window", "")
        burst_window_duration:render("Burst Duration (sec)", "")
        burst_min_elites:render("Auto Burst at X+ Elites", "")
        burst_on_boss:render("Always Burst on Boss", "")
        burst_tree:pop()
    end

    if burst_combo_tree:push("Elite/Boss Burst Combo") then
        elite_boss_burst_combo:render("Iron Skin + Challenging Shout + War Cry", "")
        burst_combo_requires_boss_or_multi:render("Only on Boss or 2+ Elites", "")
        burst_combo_tree:pop()
    end

    if shouts_finishers_tree:push("Shouts & Finishers") then
        aggressive_shouts:render("Aggressive Shouts on Packs", "")
        use_finishers_on_elites:render("Rupture/Death Blow on Low HP Elites", "")
        shouts_finishers_tree:pop()
    end

    menu.main_tree:pop()
end)

local build_profiles = {}
pcall(function() build_profiles = require("build_profiles") or {} end)

local cast_end_time = 0.0

local last_ancients_cast_time = 0.0
local last_boss_ancients_cast_time = 0.0
local last_wrath_cast_time = 0.0
local last_elite_seen_time = 0.0
local last_boss_seen_time = 0.0

-- Simulated "ancients are still up" timer (backup when the real buff hash isn't working yet)
local ancients_summon_active_until = 0.0

-- Sticky flag so CoA truly casts only once per engagement until a full disengage (per the menu slider)
local ancients_used_this_engagement = false

on_update(function()
    local player = get_local_player()
    if not player then return end

    if player:is_dead() then
        last_ancients_cast_time = 0.0
        last_boss_ancients_cast_time = 0.0
        last_wrath_cast_time = 0.0
        last_elite_seen_time = 0.0
        last_boss_seen_time = 0.0
        ancients_used_this_engagement = false
        ancients_summon_active_until = 0.0

        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then spells.call_of_the_ancients.reset() end
        if spells.challenging_shout and spells.challenging_shout.reset then spells.challenging_shout.reset() end
        if spells.iron_skin and spells.iron_skin.reset then spells.iron_skin.reset() end
        if spells.war_cry and spells.war_cry.reset then spells.war_cry.reset() end
        if spells.rallying_cry and spells.rallying_cry.reset then spells.rallying_cry.reset() end
        return
    end

    if cast_spell.is_channel_spell_active(206435) then
        cast_spell.update_channel_spell_position(206435, get_cursor_position())
    end

    if menu.main_boolean:get() == false then return end

    local now = get_time_since_inject()
    if now < cast_end_time then return end
    if not my_utility.is_action_allowed() then return end

    -- Data
    local is_auto = auto_play.is_active()
    local max_range = is_auto and 12.0 or 8.5
    local screen_range = is_auto and 20.0 or 16.0

    local selected_pos = my_target_selector.get_current_selected_position()
    local entities = my_target_selector.get_target_list(selected_pos, screen_range, {false,2.0}, {true,5.0}, {false,90.0})
    local ts_data = my_target_selector.get_target_selector_data(selected_pos, entities)
    if not ts_data.is_valid then return end

    local best = ts_data.closest_unit
    if ts_data.has_boss then best = ts_data.closest_boss
    elseif ts_data.has_elite then best = ts_data.closest_elite
    elseif ts_data.has_champion then best = ts_data.closest_champion end

    if not best then return end
    if best:get_position():squared_dist_to_ignore_z(selected_pos) > (max_range * max_range) then
        best = ts_data.closest_unit
        if best:get_position():squared_dist_to_ignore_z(selected_pos) > (max_range * max_range) then return end
    end

    local player_pos = player:get_position()
    local hp_pct = (player:get_current_health() / player:get_max_health()) * 100
    local fury_pct = (player:get_primary_resource_current() / player:get_primary_resource_max()) * 100

    local close_count = 0
    local elite_near = 0
    for _, e in ipairs(actors_manager.get_enemy_npcs()) do
        if player_pos:dist_to(e:get_position()) < 7.0 then
            close_count = close_count + 1
            if e:is_elite() or e:is_boss() or e:is_champion() then elite_near = elite_near + 1 end
        end
    end

    local has_priority = ts_data.has_boss or ts_data.has_elite or ts_data.has_champion or elite_near > 0

    if ts_data.has_boss then last_boss_seen_time = now end
    if has_priority then last_elite_seen_time = now end

    -- Robust "still in priority fight" detection using the full target list (16-20yd range).
    -- This prevents false disengages (and thus CoA spam) while elites/bosses are still on screen during a pack or boss fight.
    for _, e in ipairs(entities) do
        if e:is_elite() or e:is_boss() or e:is_champion() then
            last_elite_seen_time = now
            break
        end
    end

    -- ============================================
    -- Call of the Ancients - Cast ONCE per engagement / boss / big pack
    -- - Sticky flag + 7s hard floor + 5s summon timer + spell's 300s throttle = protection against multiple casts on the same elites.
    -- - Time-based re-arm for flag has 60s minimum floor (to prevent re-casting on same pack).
    -- - Fast re-arm for genuinely new packs happens on actual disengage (no elites seen for your slider time) OR 240s.
    -- - We deliberately avoid clearing the spell throttle on time-based re-arms.
    -- - Quality is handled entirely in the CoA submenu.
    -- - NEW: call_of_the_ancients_passive buff gate (ID 2506505, in both main.lua + spell logics) — while the buff is up we never cast.
    --   This guarantees CoA fires at most once per elite/boss pack and only when the previous summon has fully ended.
    -- ============================================
    local disengage_time = math.max(15.0, ancients_reset_delay:get())

    -- True disengage re-arm (prevents spam on the same pack/boss)
    local time_since_last_ancients = now - last_ancients_cast_time
    if (now - last_elite_seen_time) > disengage_time then
        last_ancients_cast_time = 0.0
        last_boss_ancients_cast_time = 0.0
        ancients_used_this_engagement = false
        -- Note: We intentionally do NOT clear ancients_summon_active_until here.
        -- The 5s summon timer should stay as hard protection during an active CoA.

        -- Clear the spell's throttle on a real new engagement so it can cast promptly for the next pack/boss
        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then
            spells.call_of_the_ancients.reset()
        end
    end

    -- Very long hard safety for marathon fights (still once-per-fight in practice).
    -- Also clear the spell's throttle here so a cast can happen promptly after the safety window.
    if last_ancients_cast_time > 0 and time_since_last_ancients > 240.0 then
        ancients_used_this_engagement = false
        -- Keep the summon timer as protection; only clear the long-term engagement flag here.
        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then
            spells.call_of_the_ancients.reset()
        end
    end

    -- Controlled re-arm for new packs only (time-based, no actual disengage required).
    -- We use a higher floor here (60s minimum) so the sticky flag doesn't clear too quickly on the *same* pack/fight
    -- even if your slider is set very low. This is what was allowing the second cast right after the 5s timer expired.
    -- True fast reactivation for *new* packs should come from actual disengage (no elites seen for your slider time).
    local min_time_between_packs = math.max(60, ancients_reset_delay:get())
    if last_ancients_cast_time > 0 and time_since_last_ancients > min_time_between_packs then
        ancients_used_this_engagement = false
        -- Do NOT clear ancients_summon_active_until here.
        -- The short 5s summon timer protection should remain independent of long-term re-arming.
        -- Note: we intentionally do NOT call spell.reset() here to preserve its strong throttle.
    end

    -- CoA consideration gate (timing/engagement only).
    -- Offers on bosses/champions or elite signals.
    -- We add an explicit hard 75s minimum time gate here (independent of the flag) as strong protection
    -- against multiple casts on the same elites even if the flag gets cleared early for any reason.
    local good_for_coa = ts_data.has_boss 
                      or ts_data.has_champion 
                      or ts_data.has_elite 
                      or elite_near > 0

    -- Debug visibility (only active if you manually enable the "Debug: Print CoA Buffs" checkbox)
    _G.COA_DEBUG_BUFFS = coa_debug_buffs:get()

    local coa_debug = coa_debug_buffs:get()
    if spells.call_of_the_ancients and spells.call_of_the_ancients.menu_elements then
        local dbg = spells.call_of_the_ancients.menu_elements.debug_buffs
        if dbg then coa_debug = coa_debug or dbg:get() end
    end
    if good_for_coa and coa_debug then
        -- Only print this summary occasionally so it doesn't spam
        if math.floor(now) % 3 == 0 then
            console.print(string.format("[CoA Main] good_for_coa=true | since_last=%.1fs | flag=%s", 
                time_since_last_ancients, tostring(ancients_used_this_engagement)))
        end
    end

    -- ============================================
    -- TEMPORARY: Real buff detection (2506505 + string matching) is DISABLED.
    -- It was producing false positives and blocking valid casts (or causing hangs when debug was on).
    -- Current protection relies on:
    --   - ancients_summon_active_until (5s timer started on successful cast)
    --   - 7s hard minimum time gate
    --   - ancients_used_this_engagement sticky flag
    --   - 300s internal throttle in the spell file
    --   - Disengage timer (controlled by your "Minimum Time Between CoA" slider)
    -- ============================================

    local has_coa_passive = false

    -- Timer-based protection (5s summon duration - main short-term protection against re-casting while Ancients are active)
    if now < ancients_summon_active_until then
        has_coa_passive = true
    end

    -- Note: We deliberately do NOT call has_ancients_buff() here right now
    -- because the current ID/string logic was unreliable.

    if has_coa_passive then
        ancients_used_this_engagement = true
        console.print("[CoA] Blocking because summon timer still active (5s protection)")
    end

    -- Hard floor: never allow another CoA this soon after the previous one.
    -- Lowered to 7s (very aggressive) because the 5s summon timer is now the main protection against casting while Ancients are up.
    if time_since_last_ancients < 7 then
        if coa_debug and good_for_coa then
            console.print(string.format("[CoA] Not casting - still within 7s hard floor (since_last=%.1fs)", time_since_last_ancients))
        end
    elseif good_for_coa and not ancients_used_this_engagement and not has_coa_passive then
        if spells.call_of_the_ancients and spells.call_of_the_ancients.logics() then
            ancients_used_this_engagement = true
            last_ancients_cast_time = now
            last_boss_ancients_cast_time = now
            ancients_summon_active_until = now + 5.0   -- reduced to 5s as requested
            cast_end_time = now + 2.5
            console.print("[CoA] Successfully cast via main gate")
            return
        end
    elseif good_for_coa and coa_debug then
        -- Helpful debug so you can see exactly why it's not offering when good_for_coa=true
        local reason = ""
        if ancients_used_this_engagement then reason = reason .. "flag still set; " end
        if has_coa_passive then reason = reason .. "summon timer active; " end
        if time_since_last_ancients < 7 then reason = reason .. "under 7s floor; " end
        console.print("[CoA] good_for_coa=true but blocked: " .. reason .. "since_last=" .. string.format("%.1f", time_since_last_ancients))
    end

    local profile_name = build_profile_options[build_profile:get() + 1] or "Balanced Hybrid"
    local profile = build_profiles.get and build_profiles.get(profile_name) or {}

    local in_burst = false
    if burst_window_mode:get() and has_priority then
        if (now - last_ancients_cast_time) < burst_window_duration:get() then in_burst = true end
        if (now - last_wrath_cast_time) < 10.0 then in_burst = true end
        if elite_near >= burst_min_elites:get() then in_burst = true end
        if burst_on_boss:get() and ts_data.has_boss then in_burst = true end
    end

    -- War Cry
    if has_priority and spells.war_cry and spells.war_cry.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Challenging Shout
    if has_priority and spells.challenging_shout and spells.challenging_shout.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Rallying Cry
    if has_priority and spells.rallying_cry and spells.rallying_cry.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Iron Skin 24/7
    if maintain_resolve_defensives:get() and spells.iron_skin and spells.iron_skin.logics() then
        cast_end_time = now + 0.2
        return
    end

    -- Wrath
    if has_priority and spells.wrath_of_the_berserk and spells.wrath_of_the_berserk.logics() then
        last_wrath_cast_time = now
        cast_end_time = now + 0.25
        return
    end

    -- Burst Combo
    local do_combo = false
    if elite_boss_burst_combo:get() and has_priority then
        do_combo = not burst_combo_requires_boss_or_multi:get() or ts_data.has_boss or elite_near >= 2
    end
    if do_combo then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = now + 0.08 end
        if (burst_combo_requires_boss_or_multi:get() or ts_data.has_boss) and spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = now + 0.08 end
        if spells.war_cry and spells.war_cry.logics() then cast_end_time = now + 0.08 end
        if cast_end_time > now then return end
    end

    -- Low HP defensives
    if hp_pct < health_threshold:get() then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = now + 0.25; return end
        if spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = now + 0.2; return end
    end

    -- Whirlwind (hardcoded defaults after removing the menu section to fix crashes)
    local want_ww = false
    local ww_fury_threshold = 28
    local whirlwind_burst_elite = true
    local ww_min_enemies = 2
    local good_fury = fury_pct >= (ww_fury_threshold / 100)
    if (whirlwind_burst_elite or (profile.constant_ww_priority)) and has_priority and good_fury then
        want_ww = true
    elseif close_count >= ww_min_enemies and good_fury then
        want_ww = true
    end
    if in_burst and good_fury then want_ww = true end

    if want_ww and spells.whirl_wind and spells.whirl_wind.logics(best) then
        cast_end_time = now + 0.28
        return
    end

    -- Smart Ground Stomp
    if smart_ground_stomp:get() and close_count >= ground_stomp_min_enemies:get() then
        if spells.ground_stomp and spells.ground_stomp.logics(best) then
            cast_end_time = now + 0.3
            return
        end
    end

    -- Steel Grasp
    if has_priority and steel_grasp_on_elites:get() then
        if spells.steel_grasp and spells.steel_grasp.logics(entities, ts_data, best) then
            cast_end_time = now + 0.2
            return
        end
    end

    -- Generators
    local lunging_fury_limit = 32   -- hardcoded default (was previously in removed Whirlwind menu)
    if fury_pct < (lunging_fury_limit / 100) then
        local pref = profile.preferred_generator or "lunging_strike"
        if spells[pref] and spells[pref].logics(entities) then cast_end_time = now + 0.15; return end
        for _, gen in ipairs(profile.secondary_generators or {"lunging_strike","bash","flay","frenzy"}) do
            if spells[gen] and spells[gen].logics(entities) then cast_end_time = now + 0.15; return end
        end
    end

    -- Finishers
    if use_finishers_on_elites:get() and has_priority and best:get_current_health() / best:get_max_health() < 0.35 then
        if spells.rupture and spells.rupture.logics(best) then cast_end_time = now + 0.6; return end
        if spells.death_blow and spells.death_blow.logics(best) then cast_end_time = now + 0.3; return end
    end

    if spells.lunging_strike and spells.lunging_strike.logics(entities) then cast_end_time = now + 0.12; return end
    if spells.bash and spells.bash.logics(entities) then cast_end_time = now + 0.1; return end
end)

on_render(function()
    if not menu.main_boolean:get() then return end
    local p = get_local_player()
    if not p then return end

    local selected = my_target_selector.get_current_selected_position()
    local ts = my_target_selector.get_target_selector_data(selected, my_target_selector.get_target_list(selected, 16, {false,2}, {true,5}, {false,90}))
    if not ts.is_valid then return end

    local target = ts.closest_unit
    if ts.has_boss then target = ts.closest_boss
    elseif ts.has_elite then target = ts.closest_elite end

    if target then
        local tpos = target:get_position()
        local ppos = p:get_position()
        local t2d = graphics.w2s(tpos)
        local p2d = graphics.w2s(ppos)
        if not t2d:is_zero() and not p2d:is_zero() then
            graphics.line(t2d, p2d, color_red(180), 2.5)
            graphics.circle_3d(tpos, 0.8, color_red(200), 2)
        end
    end
end)

console.print("[V1per Barb]")