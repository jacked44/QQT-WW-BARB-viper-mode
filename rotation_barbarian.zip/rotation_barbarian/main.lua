local local_player = get_local_player()
if local_player == nil then
    return
end

-- Class guard: only load on Barbarian (class ID 1)
local character_id = local_player:get_character_class_id()
if character_id ~= 1 then
    return
end

console.print("[V1per Barb] Script parsed successfully. Waiting for full init...")

local my_target_selector = require("my_utility/my_target_selector")
local my_utility = require("my_utility/my_utility")
local max_size = vec2:new(500, 800)
local min_size = vec2:new(400, 100)
graphics.set_menu_constraints_special_fnc(max_size, min_size)

local menu = require("menu")

-- === Consolidated Menu Elements (declared once, early) ===
local targeting_mode_options = {"cursor", "player"}
local targeting_mode_dropdown = combo_box:new(0, get_hash("targeting_mode_dropdown"))

local spell_dropdown = combo_box:new(0, get_hash("spell_dropdown"))
local spell_options = {"None", "lunging_strike", "whirl_wind", "bash", "frenzy", "flay",
    "hammer_of_ancients", "upheaval", "double_swing", "rend",
    "rallying_cry", "challenging_shout", "war_cry", "iron_skin",
    "ground_stomp", "kick", "charge", "leap", "rupture", "death_blow",
    "wrath_of_the_berserk", "call_of_the_ancients", "steel_grasp"}

local build_profile_options = {"WW Spin (Meta)", "Minion Ancients Burst (Meta)", "HoTA Focused", "Balanced Hybrid"}
local build_profile = combo_box:new(0, get_hash("build_profile_viper"))

local whirlwind_burst_elite = checkbox:new(true, get_hash("whirlwind_burst_elite"))
local ww_fury_threshold = slider_int:new(10, 60, 28, get_hash("ww_fury_threshold"))
local ww_min_enemies = slider_int:new(1, 10, 2, get_hash("ww_min_enemies"))
local only_ww_on_elites = checkbox:new(false, get_hash("only_ww_on_elites"))
local lunging_fury_limit = slider_int:new(10, 60, 32, get_hash("lunging_fury_limit"))
local health_threshold = slider_int:new(15, 75, 40, get_hash("health_threshold_defensives"))

local smart_ground_stomp = checkbox:new(true, get_hash("smart_ground_stomp"))
local ground_stomp_min_enemies = slider_int:new(1, 10, 3, get_hash("ground_stomp_min_enemies"))
local steel_grasp_on_elites = checkbox:new(true, get_hash("steel_grasp_on_elites"))

local burst_window_mode = checkbox:new(true, get_hash("burst_window_mode"))
local burst_window_duration = slider_int:new(5, 20, 10, get_hash("burst_window_duration_viper"))
local burst_min_elites = slider_int:new(1, 5, 2, get_hash("burst_min_elites_viper"))
local burst_on_boss = checkbox:new(true, get_hash("burst_on_boss_viper"))

local aggressive_shouts = checkbox:new(true, get_hash("aggressive_shouts_viper"))
local use_finishers_on_elites = checkbox:new(true, get_hash("use_finishers_on_elites"))
local maintain_resolve_defensives = checkbox:new(true, get_hash("maintain_resolve_defensives"))

local debug_print_shout_buffs = checkbox:new(false, get_hash("debug_print_shout_buffs_viper"))

local ancients_reset_delay = slider_int:new(5, 90, 25, get_hash("ancients_reset_delay_viper"))

local function render_selected_spell_menu()
    local selected_index = spell_dropdown:get() + 1
    if selected_index > 0 and selected_index <= #spell_options then
        local selected_spell = spell_options[selected_index]
        if selected_spell ~= "None" and spells[selected_spell] and spells[selected_spell].menu then
            spells[selected_spell].menu()
        end
    end
end

-- Clean, complete menu (restored full original controls)
on_render_menu(function ()
    if not menu.main_tree:push("Barbarian: V1per Mode (Dynamic - Equipped Skills)") then
        return
    end

    menu.main_boolean:render("Enable Plugin", "")

    if menu.main_boolean:get() == false then
        menu.main_tree:pop()
        return
    end

    targeting_mode_dropdown:render("Targeting Mode", targeting_mode_options, "Target closest to PLAYER or closest to CURSOR")
    spell_dropdown:render("Select Spell", spell_options, "Choose a spell to configure")

    build_profile:render("Build Profile", build_profile_options, "Select your playstyle. WW Spin and Minion Ancients are S-tier meta Season 13+")

    ancients_reset_delay:render("Ancients Group Lockout (sec)", "Seconds you must go with ZERO elites/bosses visible before allowing next cast. Default 25s = very safe 'once per group'")

    whirlwind_burst_elite:render("Whirlwind Elite Burst", "Prioritize Whirlwind on elites, bosses and champions")
    only_ww_on_elites:render("Only Whirlwind on Elites", "Only spin when elites or bosses are nearby")
    ww_fury_threshold:render("Whirlwind Fury Threshold %", "Minimum Fury % required to use Whirlwind (lower = more uptime)")
    ww_min_enemies:render("Minimum Enemies for Whirlwind", "Only use Whirlwind when this many enemies are close")
    lunging_fury_limit:render("Lunging Strike Fury Limit %", "Prefer Lunging Strike as generator below this %. The rotation will not start Whirlwind until at least 60% fury (hard floor for building phase)")

    health_threshold:render("Health % for Defensives", "Auto use Iron Skin / Challenging Shout below this HP %")
    maintain_resolve_defensives:render("Maintain Resolve Defensives", "Cast Iron Skin on elites even above HP% (Tibault's Will / Resolve procs)")
    smart_ground_stomp:render("Smart Ground Stomp", "Use Ground Stomp to group enemies before spinning")
    ground_stomp_min_enemies:render("Ground Stomp Min Enemies", "Minimum enemies required to use Smart Ground Stomp")
    steel_grasp_on_elites:render("Steel Grasp on Elites Only", "Only use Steel Grasp when elites or bosses are nearby")

    burst_window_mode:render("Burst Window Mode", "Enable smart burst detection focused on elites & bosses")
    burst_window_duration:render("Burst Window Duration (sec)", "How long after Call of the Ancients / Wrath to stay in burst spender mode")
    burst_min_elites:render("Auto-Burst on X+ Elites", "Start spending big cooldowns when this many elites are nearby")
    burst_on_boss:render("Always Burst on Boss", "Treat any boss as an automatic burst window for spenders")

    aggressive_shouts:render("Aggressive Shouts", "Cast War/Rallying Cry proactively on elites/packs for buffs (meta for WW & Minion)")
    use_finishers_on_elites:render("Elite Finishers", "Use Rupture / Death Blow on low HP elites and bosses")

    debug_print_shout_buffs:render("Debug: Print Shout Buffs", "Temporarily enable while fighting to see exact buff names/hashes in console")

    render_selected_spell_menu()
    menu.main_tree:pop()
end)

-- Safe loading with error protection so the menu always appears
local equipped_skills = {}
local build_profiles = {}
local spells = {}

local function safe_require(name)
    local ok, mod = pcall(require, name)
    if not ok then
        console.print("[V1per Barb] WARNING: Failed to load '" .. name .. "': " .. tostring(mod))
        return nil
    end
    return mod
end

local ok, err = pcall(function()
    equipped_skills = safe_require("equipped_skills") or {}
    build_profiles = safe_require("build_profiles") or {}

    -- Minimal fallback for equipped_skills if the module failed
    if not equipped_skills.is_equipped then
        equipped_skills.is_equipped = function() return true end
        equipped_skills.get_equipped_modules = function() return {} end
    end

    -- Dynamically load only equipped spells
    local function load_spells()
        local loaded = {}
        local possible = {
            "lunging_strike", "whirl_wind", "bash", "frenzy", "flay",
            "hammer_of_ancients", "upheaval", "double_swing", "rend",
            "rallying_cry", "challenging_shout", "war_cry", "iron_skin",
            "ground_stomp", "kick", "charge", "leap", "rupture", "death_blow",
            "wrath_of_the_berserk", "call_of_the_ancients", "steel_grasp"
        }

        for _, name in ipairs(possible) do
            local ok_load, spell_mod = pcall(require, "spells/" .. name)
            if ok_load and spell_mod and equipped_skills.is_equipped(name) then
                loaded[name] = spell_mod
            elseif not ok_load then
                console.print("[V1per Barb] Failed to load spell: " .. name .. " → " .. tostring(spell_mod))
            end
        end

        return loaded
    end

    spells = load_spells()
end)

if not ok then
    console.print("[V1per Barb] WARNING: Some features failed to load (see above). Basic menu is still available.")
end

console.print("[V1per Barb] Menu should now be visible.")







local cast_end_time = 0.0

-- === Call of the Ancients Variables ===
local call_of_ancients_used = false
local last_ancients_cast_time = 0.0
local last_elite_seen_time = 0.0

-- Burst tracking
local last_wrath_cast_time = 0.0

on_update(function ()
    local local_player = get_local_player()
    if not local_player then
        return
    end

    -- Channel position follow for Whirlwind (critical for QQT channel spells)
    local spell_id_whirl_wind = 206435
    if cast_spell.is_channel_spell_active(spell_id_whirl_wind) then
        cast_spell.update_channel_spell_position(spell_id_whirl_wind, get_cursor_position())
    end

    local current_orb_mode = orbwalker.get_orb_mode()
    if current_orb_mode == orb_mode.none and not my_utility.is_auto_play_enabled() then
        cast_spell.pause_all_channel_spells(0.25)
    end

    if menu.main_boolean:get() == false then
        return
    end

    local current_time = get_time_since_inject()
    if current_time < cast_end_time then
        return
    end

    if not my_utility.is_action_allowed() then
        return
    end

    -- === DATA GATHERING (standard QQT pattern) ===
    local is_auto_play_active = auto_play.is_active()
    local max_range = is_auto_play_active and 12.0 or 8.5
    local screen_range = is_auto_play_active and 20.0 or 16.0
    local collision_table = { false, 2.0 }
    local floor_table = { true, 5.0 }
    local angle_table = { false, 90.0 }

    local selected_position = my_target_selector.get_current_selected_position()
    local entity_list = my_target_selector.get_target_list(
        selected_position, screen_range, collision_table, floor_table, angle_table)

    local target_selector_data = my_target_selector.get_target_selector_data(
        selected_position, entity_list)

    if not target_selector_data.is_valid then
        return
    end

    local best_target = target_selector_data.closest_unit

    -- Elite / Boss / Champion priority (core to good Barb botting)
    if target_selector_data.has_boss then
        local unit = target_selector_data.closest_boss
        if unit:get_position():squared_dist_to_ignore_z(selected_position) < (max_range * max_range) then
            best_target = unit
        end
    elseif target_selector_data.has_elite then
        local unit = target_selector_data.closest_elite
        if unit:get_position():squared_dist_to_ignore_z(selected_position) < (max_range * max_range) then
            best_target = unit
        end
    elseif target_selector_data.has_champion then
        local unit = target_selector_data.closest_champion
        if unit:get_position():squared_dist_to_ignore_z(selected_position) < (max_range * max_range) then
            best_target = unit
        end
    end

    if not best_target then
        return
    end

    local best_target_position = best_target:get_position()
    if best_target_position:squared_dist_to_ignore_z(selected_position) > (max_range * max_range) then
        best_target = target_selector_data.closest_unit
        if best_target:get_position():squared_dist_to_ignore_z(selected_position) > (max_range * max_range) then
            return
        end
    end

    -- Player & Combat State
    local player = get_local_player()
    local player_pos = get_player_position()
    local current_hp = player:get_current_health()
    local max_hp = player:get_max_health()
    local hp_percent = (current_hp / max_hp) * 100
    local fury_current = player:get_primary_resource_current()
    local fury_max = player:get_primary_resource_max()
    local fury_perc = fury_max > 0 and (fury_current / fury_max) or 0

    -- Debug: Print shout-related buffs (enable the checkbox temporarily while fighting)
    if debug_print_shout_buffs:get() then
        local buffs = player:get_buffs() or {}
        for _, buff in ipairs(buffs) do
            local name = ""
            if type(buff.name) == "function" then name = buff:name() or "" end
            local lower = string.lower(name)
            if string.find(lower, "rally") or string.find(lower, "war") or string.find(lower, "challeng") or string.find(lower, "shout") then
                local remain = type(buff.get_remaining_time) == "function" and (buff:get_remaining_time() or -1) or -1
                console.print(string.format("[Shout Debug] name=%s | hash=%s | remain=%.1fs | stacks=%s",
                    name, tostring(buff.name_hash or 0), remain, tostring(buff.stacks or 0)))
            end
        end
    end

    -- Enemy counts (close range for WW / stomp decisions)
    local enemies = actors_manager.get_enemy_npcs()
    local close_enemy_count = 0
    local has_elite_or_boss = false
    local elite_count_near = 0

    for _, enemy in ipairs(enemies) do
        local dist = player_pos:dist_to(enemy:get_position())
        if dist < 7.0 then
            close_enemy_count = close_enemy_count + 1
            if enemy:is_elite() or enemy:is_boss() or enemy:is_champion() then
                has_elite_or_boss = true
                elite_count_near = elite_count_near + 1
            end
        end
    end

    -- Menu values
    local ww_fury_min = ww_fury_threshold:get() / 100
    local ww_min_count = ww_min_enemies:get()
    local lunging_max_fury = lunging_fury_limit:get() / 100
    local health_min = health_threshold:get()
    local gs_min_enemies = ground_stomp_min_enemies:get()

    local use_ww_burst = whirlwind_burst_elite:get()
    local only_elites_ww = only_ww_on_elites:get()
    local use_smart_stomp = smart_ground_stomp:get()
    local steel_grasp_elites_only = steel_grasp_on_elites:get()
    local use_burst_window = burst_window_mode:get()
    local use_aggressive_shouts = aggressive_shouts:get()
    local use_finishers = use_finishers_on_elites:get()
    local use_maintain_def = maintain_resolve_defensives:get()

    local selected_profile_name = build_profile_options[build_profile:get() + 1] or "Balanced Hybrid"
    local current_build_profile = build_profiles.get(selected_profile_name)

    local low_fury = fury_perc < lunging_max_fury          -- menu-driven fine tune for generator preference
    local building_fury = fury_perc < 0.60                 -- hard floor before allowing serious WW
    local low_health = hp_percent < health_min
    local good_fury_for_ww = fury_perc >= ww_fury_min
    local good_for_ww = close_enemy_count >= ww_min_count or has_elite_or_boss

    -- ============================================
    -- MODERN: Build Profile Driven Thresholds
    -- ============================================
    local fury = build_profiles.get_fury_thresholds(current_build_profile)
    local profile_wants_ww = current_build_profile.constant_ww_priority or false

    -- ============================================
    -- SMART BURST WINDOW DETECTION (Elites & Bosses)
    -- Fine-tuned for focused aggression only on priority targets
    -- ============================================
    local in_elite_burst_window = false

    if use_burst_window and has_elite_or_boss then
        -- Post-Ancients window (main Minion burst)
        if (current_time - last_ancients_cast_time) < burst_window_duration:get() then
            in_elite_burst_window = true
        end

        -- Post-Wrath window
        if (current_time - last_wrath_cast_time) < 8.0 then
            in_elite_burst_window = true
        end

        -- Big elite pull detection
        if elite_count_near >= burst_min_elites:get() then
            in_elite_burst_window = true
        end

        -- Boss fights are always burst opportunities
        if burst_on_boss:get() and target_selector_data.has_boss then
            in_elite_burst_window = true
        end
    end

    -- ============================================
    -- MODERN PRIORITY SYSTEM (Profile + Equipped Aware)
    -- This section is now much cleaner and driven by build_profiles
    -- ============================================

    -- 1. Call of the Ancients (cast ONCE per group/encounter then hold)
    -- We only allow another cast after you've been away from all priority targets
    -- (elites, bosses, champions) for the full "Ancients Group Lockout" duration.
    local ANCIENTS_COOLDOWN = current_build_profile.aggressive_ancients and 38.0 or 45.0
    local ANCIENTS_RESET_DELAY = ancients_reset_delay:get()

    -- Use the target selector's priority detection (screen range) + our close scan.
    -- This is much more reliable than a manual distance loop for bosses and spread-out elite packs.
    local in_priority_encounter = has_elite_or_boss
        or target_selector_data.has_boss
        or target_selector_data.has_elite
        or target_selector_data.has_champion

    if in_priority_encounter then
        last_elite_seen_time = current_time
    end

    -- Only reset the "already used" flag after a clean period with ZERO priority targets nearby.
    if call_of_ancients_used and (current_time - last_elite_seen_time > ANCIENTS_RESET_DELAY) then
        call_of_ancients_used = false
    end

    local try_ancients = has_elite_or_boss or 
        (current_build_profile.aggressive_ancients and close_enemy_count >= 4)

    if try_ancients
       and not call_of_ancients_used
       and (current_time - last_ancients_cast_time > ANCIENTS_COOLDOWN)
       and (current_time - last_ancients_cast_time > 30.0)
       and spells.call_of_the_ancients and spells.call_of_the_ancients.logics()
    then
        call_of_ancients_used = true
        last_ancients_cast_time = current_time
        cast_end_time = current_time + 1.8
        return
    end

    -- 2. Defensives & Shouts (profile + burst aware)
    if low_health or (use_maintain_def and has_elite_or_boss and hp_percent < 65) then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = current_time + 0.25; return end
        if spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = current_time + 0.25; return end
    end

    local try_shouts = has_elite_or_boss or in_elite_burst_window or use_aggressive_shouts
    if try_shouts then
        for _, shout in ipairs(current_build_profile.shout_order or {"war_cry", "rallying_cry"}) do
            if spells[shout] and spells[shout].logics() then
                cast_end_time = current_time + 0.2
                return
            end
        end
    end

    if spells.wrath_of_the_berserk and spells.wrath_of_the_berserk.logics() then
        last_wrath_cast_time = current_time
        cast_end_time = current_time + 0.25
        return
    end

    if (has_elite_or_boss and hp_percent < 85) or low_health then
        if spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = current_time + 0.2; return end
    end

    -- ============================================
    -- PRIORITY 4: ENGAGE / SETUP (Steel Grasp + Stomp + Gap Close)
    -- ============================================
    -- Steel Grasp on elites (pull + damage + fury gen in some builds)
    if has_elite_or_boss and steel_grasp_elites_only then
        if spells.steel_grasp and spells.steel_grasp.logics(entity_list, target_selector_data, best_target) then
            cast_end_time = current_time + 0.2
            return
        end
    elseif not steel_grasp_elites_only then
        if spells.steel_grasp and spells.steel_grasp.logics(entity_list, target_selector_data, best_target) then
            cast_end_time = current_time + 0.2
            return
        end
    end

    -- Smart Ground Stomp for WW grouping (excellent for Dust Devil uptime)
    if use_smart_stomp and close_enemy_count >= gs_min_enemies then
        if spells.ground_stomp and spells.ground_stomp.logics(best_target) then
            cast_end_time = current_time + 0.35
            return
        end
    end

    -- Simple Leap mobility (reverted style)
    local dist_to_best = player_pos:dist_to(best_target_position)

    if dist_to_best > 5.5 and spells.leap and spells.leap.logics(best_target) then
        cast_end_time = current_time + 0.25
        return
    end

    -- 3. Whirlwind (profile-aware core)
    -- Only start spinning once we have built up enough fury (hard minimum 60%)
    local min_fury_for_ww = 0.60

    local want_ww = false

    if profile_wants_ww or use_ww_burst then
        if has_elite_or_boss and good_fury_for_ww and fury_perc >= min_fury_for_ww then
            want_ww = true
        elseif close_enemy_count >= ww_min_count and good_fury_for_ww and fury_perc >= min_fury_for_ww then
            want_ww = true
        end
    end

    -- Allow WW a bit earlier only in strong burst windows (right after big cooldowns)
    if in_elite_burst_window and good_fury_for_ww and fury_perc >= (min_fury_for_ww - 0.10) then
        want_ww = true
    end

    if want_ww and fury_perc >= min_fury_for_ww and spells.whirl_wind and spells.whirl_wind.logics(best_target) then
        cast_end_time = current_time + 0.28
        return
    end

    -- Fury Building Phase: Aggressively use Lunging Strike (and generators) until 60% fury
    if building_fury or low_fury then
        if spells.lunging_strike and spells.lunging_strike.logics(entity_list) then 
            cast_end_time = current_time + 0.15 
            return 
        end
        if spells.bash and spells.bash.logics(entity_list) then cast_end_time = current_time + 0.1; return end
        if spells.flay and spells.flay.logics(best_target) then cast_end_time = current_time + 0.2; return end
        if spells.frenzy and spells.frenzy.logics(best_target) then cast_end_time = current_time + 0.2; return end
    end

    -- 4. Burst Spenders (profile + window driven)
    local high_fury = fury_perc > (fury.spender or 0.70)

    local should_spend = high_fury or in_elite_burst_window or (current_build_profile.name and string.find(current_build_profile.name, "HoTA"))

    if should_spend and has_elite_or_boss then
        for _, spender in ipairs(current_build_profile.burst_spenders or {}) do
            if spells[spender] and spells[spender].logics(best_target) then
                cast_end_time = current_time + 0.3
                return
            end
        end
    end

    -- ============================================
    -- PRIORITY 8: FINISHERS on low HP priority targets (optional meta)
    -- ============================================
    if use_finishers and has_elite_or_boss and best_target:get_current_health() / best_target:get_max_health() < 0.35 then
        if spells.rupture and spells.rupture.logics(best_target) then cast_end_time = current_time + 0.8; return end
        if spells.death_blow and spells.death_blow.logics(best_target) then cast_end_time = current_time + 0.3; return end
    end

    -- ============================================
    -- PRIORITY 9: FALLBACK WW + GENERATORS (keep pressure)
    -- ============================================
    -- Only fallback to WW if we have built up enough fury
    if fury_perc >= min_fury_for_ww and spells.whirl_wind and spells.whirl_wind.logics(best_target) then 
        cast_end_time = current_time + 0.28; 
        return 
    end
    if spells.lunging_strike and spells.lunging_strike.logics(entity_list) then 
        cast_end_time = current_time + 0.15; 
        return 
    end
    if spells.hammer_of_ancients and spells.hammer_of_ancients.logics(best_target) then cast_end_time = current_time + 0.2; return end
    if spells.bash and spells.bash.logics(entity_list) then cast_end_time = current_time + 0.08; return end

    -- Final fallback mobility (Leap / Charge / Steel Grasp)
    if spells.leap and spells.leap.logics(best_target) then cast_end_time = current_time + 0.25; return end
    if spells.charge and spells.charge.logics(best_target) then cast_end_time = current_time + 0.15; return end
    if spells.steel_grasp and spells.steel_grasp.logics(entity_list, target_selector_data, best_target) then cast_end_time = current_time + 0.2; return end

    local selected_targeting_mode = targeting_mode_options[targeting_mode_dropdown:get() + 1]
    my_target_selector.set_targeting_mode(selected_targeting_mode)

    -- Orbwalking support when holding clear mode
    local current_orb_mode = orbwalker.get_orb_mode()
    if current_orb_mode == orb_mode.clear and my_utility.is_auto_play_enabled() then
        if best_target then
            local move_pos = best_target:get_position()
            pathfinder.request_move(move_pos)
        elseif selected_position then
            pathfinder.request_move(selected_position)
        end
    end
end)

-- Render Section
local draw_player_circle = false
local draw_enemy_circles = false

on_render(function ()
    if menu.main_boolean:get() == false then
        return
    end

    local local_player = get_local_player()
    if not local_player then
        return
    end

    local selected_position = my_target_selector.get_current_selected_position()
    local player_position = local_player:get_position()
    local player_screen_position = graphics.w2s(player_position)

    if player_screen_position:is_zero() then
        return
    end

    if draw_player_circle then
        graphics.circle_3d(player_position, 8, color_white(85), 3.5, 144)
        graphics.circle_3d(player_position, 6, color_white(85), 2.5, 144)
    end

    if draw_enemy_circles then
        local enemies = actors_manager.get_enemy_npcs()
        for _, obj in ipairs(enemies) do
            local position = obj:get_position()
            graphics.circle_3d(position, 1, color_white(100))
            local future_position = prediction.get_future_unit_position(obj, 0.4)
            graphics.circle_3d(future_position, 0.5, color_yellow(100))
        end
    end

    local screen_range = 16.0
    local cursor_position = get_cursor_position()
    local collision_table = { false, 2.0 }
    local floor_table = { true, 5.0 }
    local angle_table = { false, 90.0 }

    local entity_list = my_target_selector.get_target_list(
        selected_position, screen_range, collision_table, floor_table, angle_table)

    local target_selector_data = my_target_selector.get_target_selector_data(
        selected_position, entity_list)

    if not target_selector_data.is_valid then
        return
    end

    local best_target = target_selector_data.closest_unit
    if target_selector_data.has_elite then best_target = target_selector_data.closest_elite end
    if target_selector_data.has_boss then best_target = target_selector_data.closest_boss end
    if target_selector_data.has_champion then best_target = target_selector_data.closest_champion end

    if best_target and best_target:is_enemy() then
        local glow_target_position = best_target:get_position()
        local glow_target_position_2d = graphics.w2s(glow_target_position)
        graphics.line(glow_target_position_2d, player_screen_position, color_red(180), 2.5)
        graphics.circle_3d(glow_target_position, 0.80, color_red(200), 2.0)
    end

    -- Direction line toward cursor (useful for ground-targeted skills like Rend)
    local cursor_position = get_cursor_position()
    local cursor_screen = graphics.w2s(cursor_position)
    if not cursor_screen:is_zero() then
        graphics.line(player_screen_position, cursor_screen, color_yellow(130), 2.0)
    end
end)

console.print("Lua Plugin - Barbarian: V1per Mode (Minion) v4.0 - Profile & Equipped Skills Aware")