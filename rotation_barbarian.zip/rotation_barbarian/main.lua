local local_player = get_local_player()
if local_player == nil then return end
if local_player:get_character_class_id() ~= 1 then return end

console.print("[V1per Barb] CoA elite lockout removed - now casts more freely on elites")

local my_target_selector = require("my_utility/my_target_selector")
local my_utility = require("my_utility/my_utility")
local menu = require("menu")

local menu_spells = {
    lunging_strike = require("spells/lunging_strike"),
    whirl_wind = require("spells/whirl_wind"),
    bash = require("spells/bash"),
    frenzy = require("spells/frenzy"),
    flay = require("spells/flay"),
    hammer_of_ancients = require("spells/hammer_of_ancients"),
    upheaval = require("spells/upheaval"),
    double_swing = require("spells/double_swing"),
    rend = require("spells/rend"),
    rallying_cry = require("spells/rallying_cry"),
    challenging_shout = require("spells/challenging_shout"),
    war_cry = require("spells/war_cry"),
    iron_skin = require("spells/iron_skin"),
    ground_stomp = require("spells/ground_stomp"),
    kick = require("spells/kick"),
    charge = require("spells/charge"),
    leap = require("spells/leap"),
    rupture = require("spells/rupture"),
    death_blow = require("spells/death_blow"),
    wrath_of_the_berserk = require("spells/wrath_of_the_berserk"),
    call_of_the_ancients = require("spells/call_of_the_ancients"),
    steel_grasp = require("spells/steel_grasp"),
}
local spells = menu_spells

-- Menu
local targeting_mode_dropdown = combo_box:new(0, get_hash("targeting_mode_dropdown"))
local spell_dropdown = combo_box:new(0, get_hash("spell_dropdown"))
local spell_options = {"None","lunging_strike","whirl_wind","bash","frenzy","flay","hammer_of_ancients","upheaval","double_swing","rend","rallying_cry","challenging_shout","war_cry","iron_skin","ground_stomp","kick","charge","leap","rupture","death_blow","wrath_of_the_berserk","call_of_the_ancients","steel_grasp"}
local build_profile = combo_box:new(0, get_hash("build_profile_viper"))
local build_profile_options = {"WW Spin (Meta)", "Minion Ancients Burst (Meta)", "HoTA Focused", "Balanced Hybrid"}

local whirlwind_burst_elite = checkbox:new(true, get_hash("whirlwind_burst_elite"))
local ww_fury_threshold = slider_int:new(10, 60, 28, get_hash("ww_fury_threshold"))
local ww_min_enemies = slider_int:new(1, 10, 2, get_hash("ww_min_enemies"))
local only_ww_on_elites = checkbox:new(false, get_hash("only_ww_on_elites"))
local disable_orbwalker_movement_in_clear = checkbox:new(false, get_hash("disable_orbwalker_movement_in_clear"))
local lunging_fury_limit = slider_int:new(10, 60, 32, get_hash("lunging_fury_limit"))
local health_threshold = slider_int:new(15, 75, 40, get_hash("health_threshold_defensives"))
local smart_ground_stomp = checkbox:new(true, get_hash("smart_ground_stomp"))
local ground_stomp_min_enemies = slider_int:new(1, 10, 3, get_hash("ground_stomp_min_enemies"))
local steel_grasp_on_elites = checkbox:new(true, get_hash("steel_grasp_on_elites"))
local burst_window_mode = checkbox:new(true, get_hash("burst_window_mode"))
local burst_window_duration = slider_int:new(5, 20, 10, get_hash("burst_window_duration_viper"))
local burst_min_elites = slider_int:new(1, 5, 2, get_hash("burst_min_elites_viper"))
local burst_on_boss = checkbox:new(true, get_hash("burst_on_boss_viper"))
local aggressive_shouts = checkbox:new(true, get_hash("aggressive_shouts_viper"))
local use_finishers_on_elites = checkbox:new(true, get_hash("use_finishers_on_elites"))
local maintain_resolve_defensives = checkbox:new(true, get_hash("maintain_resolve_defensives"))
local elite_boss_burst_combo = checkbox:new(true, get_hash("elite_boss_burst_combo_viper"))
local burst_combo_requires_boss_or_multi = checkbox:new(false, get_hash("burst_combo_requires_boss_or_multi_viper"))
local ancients_reset_delay = slider_int:new(5, 90, 25, get_hash("ancients_reset_delay_viper"))

local ancients_tree = tree_node:new(0)
local ww_settings_tree = tree_node:new(0)
local defensives_tree = tree_node:new(0)
local burst_tree = tree_node:new(0)
local burst_combo_tree = tree_node:new(0)
local shouts_finishers_tree = tree_node:new(0)

local function render_selected_spell_menu()
    local idx = spell_dropdown:get() + 1
    if idx > 0 and idx <= #spell_options then
        local name = spell_options[idx]
        if name ~= "None" and menu_spells[name] and menu_spells[name].menu then
            menu_spells[name].menu()
        end
    end
end

on_render_menu(function()
    if not menu.main_tree:push("Barbarian: V1per WW - CoA Elite Lockout Removed") then return end
    menu.main_boolean:render("Enable Plugin", "")
    if not menu.main_boolean:get() then menu.main_tree:pop() return end

    targeting_mode_dropdown:render("Targeting Mode", {"cursor","player"}, "")
    spell_dropdown:render("Select Spell", spell_options, "")
    render_selected_spell_menu()
    build_profile:render("Build Profile", build_profile_options, "")

    if ancients_tree:push("Call of the Ancients") then
        ancients_reset_delay:render("Elite Pack Cooldown (sec)", "")
        ancients_tree:pop()
    end

    if ww_settings_tree:push("Whirlwind") then
        whirlwind_burst_elite:render("Prioritize Elites/Bosses", "")
        only_ww_on_elites:render("Only Whirlwind on Elites", "")
        ww_fury_threshold:render("Fury % to Spin", "")
        ww_min_enemies:render("Min Enemies to Spin", "")
        lunging_fury_limit:render("Use Generator Below Fury %", "")
        disable_orbwalker_movement_in_clear:render("No Movement in Clear Mode", "")
        ww_settings_tree:pop()
    end

    if defensives_tree:push("Defensives & Utility") then
        health_threshold:render("Health % for Defensives", "")
        maintain_resolve_defensives:render("Maintain Resolve Defensives (Iron Skin off cooldown)", "")
        smart_ground_stomp:render("Smart Ground Stomp", "")
        ground_stomp_min_enemies:render("Min Enemies for Stomp", "")
        steel_grasp_on_elites:render("Steel Grasp on Elites Only", "")
        defensives_tree:pop()
    end

    if burst_tree:push("Burst Window") then
        burst_window_mode:render("Enable Burst Window", "")
        burst_window_duration:render("Burst Duration (sec)", "")
        burst_min_elites:render("Auto Burst at X+ Elites", "")
        burst_on_boss:render("Always Burst on Boss", "")
        burst_tree:pop()
    end

    if burst_combo_tree:push("Elite/Boss Burst Combo") then
        elite_boss_burst_combo:render("Iron Skin + Challenging Shout + War Cry", "")
        burst_combo_requires_boss_or_multi:render("Only on Boss or 2+ Elites", "")
        burst_combo_tree:pop()
    end

    if shouts_finishers_tree:push("Shouts & Finishers") then
        aggressive_shouts:render("Aggressive Shouts on Packs", "")
        use_finishers_on_elites:render("Rupture/Death Blow on Low HP Elites", "")
        shouts_finishers_tree:pop()
    end

    menu.main_tree:pop()
end)

local build_profiles = {}
pcall(function() build_profiles = require("build_profiles") or {} end)

local cast_end_time = 0.0

local last_ancients_cast_time = 0.0
local last_boss_ancients_cast_time = 0.0
local last_wrath_cast_time = 0.0
local last_elite_seen_time = 0.0
local last_boss_seen_time = 0.0

on_update(function()
    local player = get_local_player()
    if not player then return end

    if player:is_dead() then
        last_ancients_cast_time = 0.0
        last_boss_ancients_cast_time = 0.0
        last_wrath_cast_time = 0.0
        last_elite_seen_time = 0.0
        last_boss_seen_time = 0.0

        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then spells.call_of_the_ancients.reset() end
        if spells.challenging_shout and spells.challenging_shout.reset then spells.challenging_shout.reset() end
        if spells.iron_skin and spells.iron_skin.reset then spells.iron_skin.reset() end
        if spells.war_cry and spells.war_cry.reset then spells.war_cry.reset() end
        if spells.rallying_cry and spells.rallying_cry.reset then spells.rallying_cry.reset() end
        return
    end

    if cast_spell.is_channel_spell_active(206435) then
        cast_spell.update_channel_spell_position(206435, get_cursor_position())
    end

    if menu.main_boolean:get() == false then return end

    local now = get_time_since_inject()
    if now < cast_end_time then return end
    if not my_utility.is_action_allowed() then return end

    -- Data
    local is_auto = auto_play.is_active()
    local max_range = is_auto and 12.0 or 8.5
    local screen_range = is_auto and 20.0 or 16.0

    local selected_pos = my_target_selector.get_current_selected_position()
    local entities = my_target_selector.get_target_list(selected_pos, screen_range, {false,2.0}, {true,5.0}, {false,90.0})
    local ts_data = my_target_selector.get_target_selector_data(selected_pos, entities)
    if not ts_data.is_valid then return end

    local best = ts_data.closest_unit
    if ts_data.has_boss then best = ts_data.closest_boss
    elseif ts_data.has_elite then best = ts_data.closest_elite
    elseif ts_data.has_champion then best = ts_data.closest_champion end

    if not best then return end
    if best:get_position():squared_dist_to_ignore_z(selected_pos) > (max_range * max_range) then
        best = ts_data.closest_unit
        if best:get_position():squared_dist_to_ignore_z(selected_pos) > (max_range * max_range) then return end
    end

    local player_pos = player:get_position()
    local hp_pct = (player:get_current_health() / player:get_max_health()) * 100
    local fury_pct = (player:get_primary_resource_current() / player:get_primary_resource_max()) * 100

    local close_count = 0
    local elite_near = 0
    for _, e in ipairs(actors_manager.get_enemy_npcs()) do
        if player_pos:dist_to(e:get_position()) < 7.0 then
            close_count = close_count + 1
            if e:is_elite() or e:is_boss() or e:is_champion() then elite_near = elite_near + 1 end
        end
    end

    local has_priority = ts_data.has_boss or ts_data.has_elite or ts_data.has_champion or elite_near > 0

    if ts_data.has_boss then last_boss_seen_time = now end
    if has_priority then last_elite_seen_time = now end

    local profile_name = build_profile_options[build_profile:get() + 1] or "Balanced Hybrid"
    local profile = build_profiles.get and build_profiles.get(profile_name) or {}

    local in_burst = false
    if burst_window_mode:get() and has_priority then
        if (now - last_ancients_cast_time) < burst_window_duration:get() then in_burst = true end
        if (now - last_wrath_cast_time) < 10.0 then in_burst = true end
        if elite_near >= burst_min_elites:get() then in_burst = true end
        if burst_on_boss:get() and ts_data.has_boss then in_burst = true end
    end

    -- ============================================
    -- CoA - Elite lockout removed (more permissive on elites)
    -- ============================================
    local time_since_boss_ancients = now - last_boss_ancients_cast_time
    local time_since_last_ancients = now - last_ancients_cast_time
    local disengage_time = math.max(12.0, ancients_reset_delay:get())

    if (now - last_boss_seen_time) > disengage_time then last_boss_ancients_cast_time = 0 end

    -- Boss (light lock)
    if ts_data.has_boss and (time_since_boss_ancients > 35 or time_since_last_ancients > 25) then
        if spells.call_of_the_ancients and spells.call_of_the_ancients.logics() then
            last_ancients_cast_time = now
            last_boss_ancients_cast_time = now
            cast_end_time = now + 2.5
            return
        end
    end

    -- Elites - Lockout removed (only global time check + has_priority)
    if not ts_data.has_boss and has_priority and time_since_last_ancients > 8 then
        if spells.call_of_the_ancients and spells.call_of_the_ancients.logics() then
            last_ancients_cast_time = now
            cast_end_time = now + 2.5
            return
        end
    end

    -- War Cry
    if has_priority and spells.war_cry and spells.war_cry.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Challenging Shout
    if has_priority and spells.challenging_shout and spells.challenging_shout.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Rallying Cry
    if has_priority and spells.rallying_cry and spells.rallying_cry.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Iron Skin 24/7
    if maintain_resolve_defensives:get() and spells.iron_skin and spells.iron_skin.logics() then
        cast_end_time = now + 0.2
        return
    end

    -- Wrath
    if has_priority and spells.wrath_of_the_berserk and spells.wrath_of_the_berserk.logics() then
        last_wrath_cast_time = now
        cast_end_time = now + 0.25
        return
    end

    -- Burst Combo
    local do_combo = false
    if elite_boss_burst_combo:get() and has_priority then
        do_combo = not burst_combo_requires_boss_or_multi:get() or ts_data.has_boss or elite_near >= 2
    end
    if do_combo then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = now + 0.08 end
        if (burst_combo_requires_boss_or_multi:get() or ts_data.has_boss) and spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = now + 0.08 end
        if spells.war_cry and spells.war_cry.logics() then cast_end_time = now + 0.08 end
        if cast_end_time > now then return end
    end

    -- Low HP defensives
    if hp_pct < health_threshold:get() then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = now + 0.25; return end
        if spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = now + 0.2; return end
    end

    -- Whirlwind
    local want_ww = false
    local good_fury = fury_pct >= (ww_fury_threshold:get() / 100)
    if (whirlwind_burst_elite:get() or (profile.constant_ww_priority)) and has_priority and good_fury then
        want_ww = true
    elseif close_count >= ww_min_enemies:get() and good_fury then
        want_ww = true
    end
    if in_burst and good_fury then want_ww = true end

    if want_ww and spells.whirl_wind and spells.whirl_wind.logics(best) then
        cast_end_time = now + 0.28
        return
    end

    -- Smart Ground Stomp
    if smart_ground_stomp:get() and close_count >= ground_stomp_min_enemies:get() then
        if spells.ground_stomp and spells.ground_stomp.logics(best) then
            cast_end_time = now + 0.3
            return
        end
    end

    -- Steel Grasp
    if has_priority and steel_grasp_on_elites:get() then
        if spells.steel_grasp and spells.steel_grasp.logics(entities, ts_data, best) then
            cast_end_time = now + 0.2
            return
        end
    end

    -- Generators
    if fury_pct < (lunging_fury_limit:get() / 100) then
        local pref = profile.preferred_generator or "lunging_strike"
        if spells[pref] and spells[pref].logics(entities) then cast_end_time = now + 0.15; return end
        for _, gen in ipairs(profile.secondary_generators or {"lunging_strike","bash","flay","frenzy"}) do
            if spells[gen] and spells[gen].logics(entities) then cast_end_time = now + 0.15; return end
        end
    end

    -- Finishers
    if use_finishers_on_elites:get() and has_priority and best:get_current_health() / best:get_max_health() < 0.35 then
        if spells.rupture and spells.rupture.logics(best) then cast_end_time = now + 0.6; return end
        if spells.death_blow and spells.death_blow.logics(best) then cast_end_time = now + 0.3; return end
    end

    if spells.lunging_strike and spells.lunging_strike.logics(entities) then cast_end_time = now + 0.12; return end
    if spells.bash and spells.bash.logics(entities) then cast_end_time = now + 0.1; return end
end)

on_render(function()
    if not menu.main_boolean:get() then return end
    local p = get_local_player()
    if not p then return end

    local selected = my_target_selector.get_current_selected_position()
    local ts = my_target_selector.get_target_selector_data(selected, my_target_selector.get_target_list(selected, 16, {false,2}, {true,5}, {false,90}))
    if not ts.is_valid then return end

    local target = ts.closest_unit
    if ts.has_boss then target = ts.closest_boss
    elseif ts.has_elite then target = ts.closest_elite end

    if target then
        local tpos = target:get_position()
        local ppos = p:get_position()
        local t2d = graphics.w2s(tpos)
        local p2d = graphics.w2s(ppos)
        if not t2d:is_zero() and not p2d:is_zero() then
            graphics.line(t2d, p2d, color_red(180), 2.5)
            graphics.circle_3d(tpos, 0.8, color_red(200), 2)
        end
    end
end)

console.print("[V1per Barb] CoA elite lockout removed")