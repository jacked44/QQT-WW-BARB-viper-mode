local local_player = get_local_player()
if local_player == nil then return end
if local_player:get_character_class_id() ~= 1 then return end

console.print("[V1per Barb]")

local my_target_selector = require("my_utility/my_target_selector")
local my_utility = require("my_utility/my_utility")
local menu = require("menu")

local menu_spells = {
    lunging_strike = require("spells/lunging_strike"),
    whirl_wind = require("spells/whirl_wind"),
    bash = require("spells/bash"),
    frenzy = require("spells/frenzy"),
    flay = require("spells/flay"),
    hammer_of_ancients = require("spells/hammer_of_ancients"),
    upheaval = require("spells/upheaval"),
    double_swing = require("spells/double_swing"),
    rend = require("spells/rend"),
    rallying_cry = require("spells/rallying_cry"),
    challenging_shout = require("spells/challenging_shout"),
    war_cry = require("spells/war_cry"),
    iron_skin = require("spells/iron_skin"),
    ground_stomp = require("spells/ground_stomp"),
    kick = require("spells/kick"),
    charge = require("spells/charge"),
    leap = require("spells/leap"),
    rupture = require("spells/rupture"),
    death_blow = require("spells/death_blow"),
    wrath_of_the_berserk = require("spells/wrath_of_the_berserk"),
    call_of_the_ancients = require("spells/call_of_the_ancients"),
    steel_grasp = require("spells/steel_grasp"),
}
local spells = menu_spells

-- Menu
local targeting_mode_dropdown = combo_box:new(0, get_hash("targeting_mode_dropdown"))
local spell_dropdown = combo_box:new(0, get_hash("spell_dropdown"))
local spell_options = {"None","lunging_strike","whirl_wind","bash","frenzy","flay","hammer_of_ancients","upheaval","double_swing","rend","rallying_cry","challenging_shout","war_cry","iron_skin","ground_stomp","kick","charge","leap","rupture","death_blow","wrath_of_the_berserk","call_of_the_ancients","steel_grasp"}
local build_profile = combo_box:new(0, get_hash("build_profile_viper"))
local build_profile_options = {"Wrath of the Berserker", "Call of the Ancients"}

-- Control whether the individual spell config (from "Select Spell" dropdown) is shown.
-- Turn this off if you get menu crashes when expanding sections like Whirlwind.
local show_selected_spell_menu = checkbox:new(true, get_hash("viper_show_selected_spell_menu"))


local health_threshold = slider_int:new(15, 75, 40, get_hash("health_threshold_defensives"))
local smart_ground_stomp = checkbox:new(true, get_hash("smart_ground_stomp"))
local ground_stomp_min_enemies = slider_int:new(1, 10, 3, get_hash("ground_stomp_min_enemies"))
local steel_grasp_on_elites = checkbox:new(true, get_hash("steel_grasp_on_elites"))
local burst_window_mode = checkbox:new(true, get_hash("burst_window_mode"))
local burst_window_duration = slider_int:new(5, 20, 10, get_hash("burst_window_duration_viper"))
local burst_min_elites = slider_int:new(1, 5, 2, get_hash("burst_min_elites_viper"))
local burst_on_boss = checkbox:new(true, get_hash("burst_on_boss_viper"))
local aggressive_shouts = checkbox:new(true, get_hash("aggressive_shouts_viper"))
local use_finishers_on_elites = checkbox:new(true, get_hash("use_finishers_on_elites"))
local maintain_resolve_defensives = checkbox:new(true, get_hash("maintain_resolve_defensives"))
local elite_boss_burst_combo = checkbox:new(true, get_hash("elite_boss_burst_combo_viper"))
local burst_combo_requires_boss_or_multi = checkbox:new(false, get_hash("burst_combo_requires_boss_or_multi_viper"))
local ancients_reset_delay = slider_int:new(5, 90, 25, get_hash("ancients_reset_delay_viper"))  -- now has a very low 10s floor for fast new-pack reactivation
local coa_debug_buffs = checkbox:new(false, get_hash("coa_debug_buffs_viper"))

local show_wrath_speed_display = checkbox:new(true, get_hash("show_wrath_speed_display"))
local wrath_boss_focus = checkbox:new(false, get_hash("wrath_boss_focus"))

local ancients_tree = tree_node:new(0)
local defensives_tree = tree_node:new(0)
local burst_tree = tree_node:new(0)
local burst_combo_tree = tree_node:new(0)
local shouts_finishers_tree = tree_node:new(0)
local wrath_tree = tree_node:new(0)

local function render_selected_spell_menu()
    local idx = spell_dropdown:get() + 1
    if idx > 0 and idx <= #spell_options then
        local name = spell_options[idx]
        if name ~= "None" and menu_spells[name] and menu_spells[name].menu then
            menu_spells[name].menu()
        end
    end
end

on_render_menu(function()
    if not menu.main_tree:push("Barbarian: V1per WW") then return end
    menu.main_boolean:render("Enable Plugin", "")
    if not menu.main_boolean:get() then menu.main_tree:pop() return end

    targeting_mode_dropdown:render("Targeting Mode", {"cursor","player"}, "")
    spell_dropdown:render("Select Spell", spell_options, "")
    show_selected_spell_menu:render("Show Selected Spell Config", "Uncheck this if expanding menus (like Whirlwind) crashes the game.")
    if show_selected_spell_menu:get() then
        render_selected_spell_menu()
    end
    build_profile:render("Build Profile", build_profile_options, "")

    local current_profile = build_profile_options[build_profile:get() + 1] or "Wrath of the Berserker"

    if ancients_tree:push("Call of the Ancients") then
        ancients_reset_delay:render("Minimum Time Between CoA on Different Packs (sec)", "Controls the disengage time for fast re-arm on *new* packs after you leave the area (min 15s). The time-based flag re-arm has a 60s hard floor to stop re-casting on the *same* elites. The 5s timer + 7s floor are short courtesy delays.")
        coa_debug_buffs:render("Debug: Print CoA Buffs", "Enable this while fighting elites/bosses. It will print every buff name + hash it sees. Use this to discover the correct call_of_the_ancients_passive buff hash so we can stop multiple casts properly.")
        ancients_tree:pop()
    end

    -- Only show the Wrath of the Berserker menu when using the Wrath profile
    if current_profile == "Wrath of the Berserker" then
        if wrath_tree:push("Wrath of the Berserker") then
            show_wrath_speed_display:render("Show Clear Speed Display", "Full tracker + Death Boost + continuous idle decay (aggression slowly drops while sitting with no new elites). High aggression requires sustained speed across windows.")
            wrath_boss_focus:render("Boss Focus Mode", "When enabled: Strongly prioritizes saving Wrath for bosses. Only uses on elite packs in exceptional situations.")
            wrath_tree:pop()
        end
    end

    if defensives_tree:push("Defensives & Utility") then
        health_threshold:render("Health % for Defensives", "")
        maintain_resolve_defensives:render("Maintain Resolve Defensives (Iron Skin off cooldown)", "")
        smart_ground_stomp:render("Smart Ground Stomp", "")
        ground_stomp_min_enemies:render("Min Enemies for Stomp", "")
        steel_grasp_on_elites:render("Steel Grasp on Elites Only", "")
        defensives_tree:pop()
    end

    if burst_tree:push("Burst Window") then
        burst_window_mode:render("Enable Burst Window", "")
        burst_window_duration:render("Burst Duration (sec)", "")
        burst_min_elites:render("Auto Burst at X+ Elites", "")
        burst_on_boss:render("Always Burst on Boss", "")
        burst_tree:pop()
    end

    if burst_combo_tree:push("Elite/Boss Burst Combo") then
        elite_boss_burst_combo:render("Iron Skin + Challenging Shout + War Cry", "")
        burst_combo_requires_boss_or_multi:render("Only on Boss or 2+ Elites", "")
        burst_combo_tree:pop()
    end

    if shouts_finishers_tree:push("Shouts & Finishers") then
        aggressive_shouts:render("Aggressive Shouts on Packs", "")
        use_finishers_on_elites:render("Rupture/Death Blow on Low HP Elites", "")
        shouts_finishers_tree:pop()
    end

    menu.main_tree:pop()
end)

local build_profiles = {}
pcall(function() build_profiles = require("build_profiles") or {} end)

local cast_end_time = 0.0

local last_ancients_cast_time = 0.0
local last_boss_ancients_cast_time = 0.0
local last_wrath_cast_time = 0.0
local last_elite_seen_time = 0.0
local last_boss_seen_time = 0.0

-- Simulated "ancients are still up" timer (backup when the real buff hash isn't working yet)
local ancients_summon_active_until = 0.0

-- Sticky flag so CoA truly casts only once per engagement until a full disengage (per the menu slider)
local ancients_used_this_engagement = false

-- ============================================
-- Wrath of the Berserker - Advanced Adaptive Tracking (No CoA)
-- ============================================
local pit_start_time = 0.0
local pit_elites_encountered = 0
local pit_seen_elite_ids = {}          -- For unique counting this Pit
local recent_elite_encounters = {}     -- Rolling window: {time}
local WRATH_ROLLING_WINDOW = 180       -- 3 minutes for recent clear speed
local WRATH_SHORT_WINDOW = 60          -- 1 minute "right now" pace for fast reaction to slowing/accelerating
local WRATH_MIN_AVG_DURATION = 60      -- minimum seconds for Pit run average calculation (prevents insane early-run numbers like 240/min on first elite)
local last_pit_zone_name = ""

-- Wrath Clear Speed Display (visible on screen)
local wrath_rolling_speed = 0.0        -- elites per minute (last 3 min) - current Pit
local wrath_average_speed = 0.0        -- elites per minute (whole current Pit run, stabilized with min duration floor)
local wrath_clear_speed_rating = 1.0   -- combined rating used for decisions

-- Persisted values from the last completed Pit (so display can stay visible after leaving)
local last_wrath_rolling_speed = 0.0
local last_wrath_average_speed = 0.0
local last_wrath_clear_speed_rating = 1.0

-- Elite kill counter (actual kills, not just encountered)
local pit_elites_killed = 0
local pit_elite_health_cache = {}      -- id -> last known health
local last_pit_elites_killed = 0
local last_pit_elites_encountered = 0   -- still used internally for speed calc if needed

-- For detecting "I'm stuck on the current elites for a long time" (no new discoveries)
local last_new_elite_time = 0.0

-- Death-based aggression boost for Wrath (resets only when entering Temis)
local pit_death_count = 0
local last_pit_death_count = 0

-- One-shot death detection so we don't increment the boost every frame while dead
local was_dead_last_update = false   -- prevents counting the same death multiple times while is_dead() stays true

-- Helper: count how many elite encounters happened in the last N seconds (list is time-sorted ascending)
local function count_elite_encounters_in_window(encounters, now, window_seconds)
    if not encounters or #encounters == 0 then return 0 end
    local cutoff = now - window_seconds
    local count = 0
    for i = #encounters, 1, -1 do
        if encounters[i] < cutoff then break end
        count = count + 1
    end
    return count
end

on_update(function()
    local player = get_local_player()
    if not player then return end

    local is_dead_now = player:is_dead()

    -- One-shot death detection (only count the transition into death, not every frame while dead)
    if is_dead_now and not was_dead_last_update then
        -- Player just died this update tick
        last_ancients_cast_time = 0.0
        last_boss_ancients_cast_time = 0.0
        last_wrath_cast_time = 0.0
        last_elite_seen_time = 0.0
        last_boss_seen_time = 0.0
        last_new_elite_time = 0.0

        -- Death aggression boost: only counts while inside a Pit run
        local death_zone = world.get_current_world()
        death_zone = death_zone and death_zone:get_current_zone_name() or ""
        if string.lower(death_zone):find("pit") then
            pit_death_count = pit_death_count + 1
            console.print(string.format("[Wrath] Death #%d this Pit run. Wrath will now be more aggressive on elites (resets only when entering Temis).", pit_death_count))
        end

        ancients_used_this_engagement = false
        ancients_summon_active_until = 0.0

        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then spells.call_of_the_ancients.reset() end
        if spells.challenging_shout and spells.challenging_shout.reset then spells.challenging_shout.reset() end
        if spells.iron_skin and spells.iron_skin.reset then spells.iron_skin.reset() end
        if spells.war_cry and spells.war_cry.reset then spells.war_cry.reset() end
        if spells.rallying_cry and spells.rallying_cry.reset then spells.rallying_cry.reset() end

        was_dead_last_update = true
        return
    end

    -- Keep the death state tracker updated
    was_dead_last_update = is_dead_now

    if is_dead_now then
        -- Still dead from previous ticks — just return (no more counting)
        return
    end


    if cast_spell.is_channel_spell_active(206435) then
        cast_spell.update_channel_spell_position(206435, get_cursor_position())
    end

    if menu.main_boolean:get() == false then return end

    local now = get_time_since_inject()
    if now < cast_end_time then return end
    if not my_utility.is_action_allowed() then return end

    -- ============================================
    -- Wrath tracking must run even when there are no enemies nearby (idle).
    -- We prune and recalculate speeds/rating early so the aggression level
    -- continues to decay naturally during idle time in the Pit.
    -- ============================================

    -- Prune old entries so rolling window is always accurate
    while #recent_elite_encounters > 0 and (now - recent_elite_encounters[1]) > WRATH_ROLLING_WINDOW do
        table.remove(recent_elite_encounters, 1)
    end

    local world = world.get_current_world()
    local current_zone = world and world:get_current_zone_name() or ""

    local currently_in_pit = string.lower(current_zone):find("pit") ~= nil
    local entering_temis = string.lower(current_zone):find("temis") ~= nil

    -- Reset / save the tracker when entering Temis, but only if there is still active Pit data.
    -- This ensures it triggers when the player goes to Temis (even after visiting other zones),
    -- and does NOT trigger on normal Pit depth changes.
    if entering_temis and (pit_start_time > 0 or #recent_elite_encounters > 0 or pit_elites_encountered > 0) then
        -- Save the completed run
        last_wrath_rolling_speed = wrath_rolling_speed
        last_wrath_average_speed = wrath_average_speed
        last_wrath_clear_speed_rating = wrath_clear_speed_rating
        last_pit_elites_encountered = pit_elites_encountered
        last_pit_elites_killed = pit_elites_killed
        last_pit_death_count = pit_death_count

        -- Clear live data
        pit_start_time = 0
        pit_elites_encountered = 0
        pit_elites_killed = 0
        pit_elite_health_cache = {}
        pit_seen_elite_ids = {}
        recent_elite_encounters = {}
        last_new_elite_time = 0
        pit_death_count = 0
        was_dead_last_update = false
        wrath_rolling_speed = 0
        wrath_average_speed = 0
        wrath_clear_speed_rating = 1.0

        console.print("[Wrath] Entered Temis - Pit run completed. Tracker reset for next attempt.")
    end

    -- Start a fresh Pit run when entering a Pit zone if we don't have an active timer
    -- (this covers coming from Temis or after a reset).
    if currently_in_pit and pit_start_time == 0 then
        pit_start_time = now
        pit_elites_encountered = 0
        pit_elites_killed = 0
        pit_elite_health_cache = {}
        pit_seen_elite_ids = {}
        recent_elite_encounters = {}
        last_new_elite_time = now
        pit_death_count = 0
        was_dead_last_update = false
        wrath_rolling_speed = 0
        wrath_average_speed = 0
        wrath_clear_speed_rating = 1.0

        console.print("[Wrath] Starting new Pit run. Tracker initialized.")
    end

    last_pit_zone_name = current_zone


    -- Recalculate speeds and aggression rating while in Pit, even with no current enemies.
    -- This is what keeps the tracker "alive" during idle time.
    -- Includes continuous idle decay (aggression slowly trends down the longer you go without discovering new elites).
    -- The run timer starts on first Pit entry and does NOT reset on depth changes.
    -- Average uses min-duration floor for sane early-run numbers.
    if string.lower(current_zone):find("pit") then
        local run_duration = (pit_start_time > 0) and (now - pit_start_time) or 1

        local rolling_count = count_elite_encounters_in_window(recent_elite_encounters, now, WRATH_ROLLING_WINDOW)
        wrath_rolling_speed = rolling_count / (WRATH_ROLLING_WINDOW / 60)

        -- Use a floor on duration for the average so the first 1-2 elites don't produce crazy numbers like 240/min
        local effective_seconds = math.max(run_duration, WRATH_MIN_AVG_DURATION)
        wrath_average_speed = (pit_elites_encountered > 0) and (pit_elites_encountered / (effective_seconds / 60)) or 0

        local short_count = count_elite_encounters_in_window(recent_elite_encounters, now, WRATH_SHORT_WINDOW)
        local short_speed = short_count / (WRATH_SHORT_WINDOW / 60)

        local base_rating = (wrath_rolling_speed * 0.50) + (short_speed * 0.30) + (wrath_average_speed * 0.20)

        local trend = 1.0
        if wrath_rolling_speed > 0.1 and short_speed > 0.05 then
            local ratio = short_speed / wrath_rolling_speed
            if ratio < 0.55 then
                trend = 0.60
            elseif ratio < 0.78 then
                trend = 0.78
            elseif ratio > 1.80 then
                trend = 1.20
            elseif ratio > 1.45 then
                trend = 1.08
            end
        end

        wrath_clear_speed_rating = base_rating * trend

        if (now - last_new_elite_time) > 55 then
            wrath_clear_speed_rating = wrath_clear_speed_rating * 0.68
        elseif (now - last_new_elite_time) > 35 then
            wrath_clear_speed_rating = wrath_clear_speed_rating * 0.82
        end

        if pit_death_count > 0 then
            local death_reduction = math.min(pit_death_count * 0.15, 0.60)
            wrath_clear_speed_rating = wrath_clear_speed_rating * (1 - death_reduction)
        end

        -- Continuous idle decay: while sitting with no new elites being discovered,
        -- the aggression rating slowly trends downward over time. This makes the
        -- tracker feel responsive and "alive" during idle periods instead of staying flat
        -- until the next 35s/55s staleness step.
        local time_since_last_elite = now - last_new_elite_time
        if time_since_last_elite > 5 then
            -- Gentle continuous decay after 5 seconds of no new elite discoveries.
            -- Adjust the 0.006 multiplier to control how fast it drops while idle.
            local idle_factor = math.max(0.35, 1.0 - (time_since_last_elite - 5) * 0.006)
            wrath_clear_speed_rating = wrath_clear_speed_rating * idle_factor
        end

        if wrath_clear_speed_rating > 2.8 then
            local excess = wrath_clear_speed_rating - 2.8
            wrath_clear_speed_rating = 2.8 + (excess * 0.65)
        end

        if wrath_clear_speed_rating < 0.10 then wrath_clear_speed_rating = 0.10 end
        if wrath_clear_speed_rating > 7.0 then wrath_clear_speed_rating = 7.0 end
    end

    -- Data

    local is_auto = auto_play.is_active()
    local max_range = is_auto and 12.0 or 8.5
    local screen_range = is_auto and 20.0 or 16.0

    local selected_pos = my_target_selector.get_current_selected_position()
    local entities = my_target_selector.get_target_list(selected_pos, screen_range, {false,2.0}, {true,5.0}, {false,90.0})
    local ts_data = my_target_selector.get_target_selector_data(selected_pos, entities)
    if not ts_data.is_valid then return end

    local best = ts_data.closest_unit
    if ts_data.has_boss then best = ts_data.closest_boss
    elseif ts_data.has_elite then best = ts_data.closest_elite
    elseif ts_data.has_champion then best = ts_data.closest_champion end

    if not best then return end
    if best:get_position():squared_dist_to_ignore_z(selected_pos) > (max_range * max_range) then
        best = ts_data.closest_unit
        if best:get_position():squared_dist_to_ignore_z(selected_pos) > (max_range * max_range) then return end
    end

    local player_pos = player:get_position()
    local hp_pct = (player:get_current_health() / player:get_max_health()) * 100
    local fury_pct = (player:get_primary_resource_current() / player:get_primary_resource_max()) * 100

    local close_count = 0
    local elite_near = 0
    for _, e in ipairs(actors_manager.get_enemy_npcs()) do
        if player_pos:dist_to(e:get_position()) < 7.0 then
            close_count = close_count + 1
            if e:is_elite() or e:is_boss() or e:is_champion() then elite_near = elite_near + 1 end
        end
    end

    local has_priority = ts_data.has_boss or ts_data.has_elite or ts_data.has_champion or elite_near > 0

    if ts_data.has_boss then last_boss_seen_time = now end
    if has_priority then last_elite_seen_time = now end

    -- Robust "still in priority fight" detection using the full target list (16-20yd range).
    -- This prevents false disengages (and thus CoA spam) while elites/bosses are still on screen during a pack or boss fight.
    for _, e in ipairs(entities) do
        if e:is_elite() or e:is_boss() or e:is_champion() then
            last_elite_seen_time = now
            break
        end
    end

    -- Elite kill tracking (adding new elites) - only needs to run when we have targets
    if string.lower(current_zone):find("pit") then
        for _, e in ipairs(entities) do
            if e:is_elite() or e:is_champion() then
                local id = nil
                pcall(function() id = e:get_id() end)
                local key = id and tostring(id) or tostring(e)

                local current_hp = 0
                pcall(function() current_hp = e:get_current_health() or 0 end)

                -- === Encounter tracking (for clear speed / aggression) ===
                if not pit_seen_elite_ids[key] then
                    pit_seen_elite_ids[key] = true
                    pit_elites_encountered = pit_elites_encountered + 1
                    last_new_elite_time = now

                    table.insert(recent_elite_encounters, now)
                end

                -- === Kill detection via health (for the visible kill counter) ===
                local previous_hp = pit_elite_health_cache[key]

                if previous_hp and previous_hp > 0 and current_hp <= 0 then
                    pit_elites_killed = pit_elites_killed + 1
                    console.print("[Pit] Elite killed! Total this run: " .. pit_elites_killed)
                end

                pit_elite_health_cache[key] = current_hp
            end
        end
    end

    -- ============================================
    -- Call of the Ancients - Cast ONCE per engagement / boss / big pack
    -- - Sticky flag + 7s hard floor + 5s summon timer + spell's 300s throttle = protection against multiple casts on the same elites.
    -- - Time-based re-arm for flag has 60s minimum floor (to prevent re-casting on same pack).
    -- - Fast re-arm for genuinely new packs happens on actual disengage (no elites seen for your slider time) OR 240s.
    -- - We deliberately avoid clearing the spell throttle on time-based re-arms.
    -- - Quality is handled entirely in the CoA submenu.
    -- - NEW: call_of_the_ancients_passive buff gate (ID 2506505, in both main.lua + spell logics) — while the buff is up we never cast.
    --   This guarantees CoA fires at most once per elite/boss pack and only when the previous summon has fully ended.
    -- ============================================
    local disengage_time = math.max(15.0, ancients_reset_delay:get())

    -- True disengage re-arm (prevents spam on the same pack/boss)
    local time_since_last_ancients = now - last_ancients_cast_time
    if (now - last_elite_seen_time) > disengage_time then
        last_ancients_cast_time = 0.0
        last_boss_ancients_cast_time = 0.0
        ancients_used_this_engagement = false
        -- Note: We intentionally do NOT clear ancients_summon_active_until here.
        -- The 5s summon timer should stay as hard protection during an active CoA.

        -- Clear the spell's throttle on a real new engagement so it can cast promptly for the next pack/boss
        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then
            spells.call_of_the_ancients.reset()
        end
    end

    -- Very long hard safety for marathon fights (still once-per-fight in practice).
    -- Also clear the spell's throttle here so a cast can happen promptly after the safety window.
    if last_ancients_cast_time > 0 and time_since_last_ancients > 240.0 then
        ancients_used_this_engagement = false
        -- Keep the summon timer as protection; only clear the long-term engagement flag here.
        if spells.call_of_the_ancients and spells.call_of_the_ancients.reset then
            spells.call_of_the_ancients.reset()
        end
    end

    -- Controlled re-arm for new packs only (time-based, no actual disengage required).
    -- We use a higher floor here (60s minimum) so the sticky flag doesn't clear too quickly on the *same* pack/fight
    -- even if your slider is set very low. This is what was allowing the second cast right after the 5s timer expired.
    -- True fast reactivation for *new* packs should come from actual disengage (no elites seen for your slider time).
    local min_time_between_packs = math.max(60, ancients_reset_delay:get())
    if last_ancients_cast_time > 0 and time_since_last_ancients > min_time_between_packs then
        ancients_used_this_engagement = false
        -- Do NOT clear ancients_summon_active_until here.
        -- The short 5s summon timer protection should remain independent of long-term re-arming.
        -- Note: we intentionally do NOT call spell.reset() here to preserve its strong throttle.
    end

    -- CoA consideration gate (timing/engagement only).
    -- Offers on bosses/champions or elite signals.
    -- We add an explicit hard 75s minimum time gate here (independent of the flag) as strong protection
    -- against multiple casts on the same elites even if the flag gets cleared early for any reason.
    local good_for_coa = ts_data.has_boss 
                      or ts_data.has_champion 
                      or ts_data.has_elite 
                      or elite_near > 0

    -- Debug visibility (only active if you manually enable the "Debug: Print CoA Buffs" checkbox)
    _G.COA_DEBUG_BUFFS = coa_debug_buffs:get()

    local coa_debug = coa_debug_buffs:get()
    if spells.call_of_the_ancients and spells.call_of_the_ancients.menu_elements then
        local dbg = spells.call_of_the_ancients.menu_elements.debug_buffs
        if dbg then coa_debug = coa_debug or dbg:get() end
    end
    if good_for_coa and coa_debug then
        -- Only print this summary occasionally so it doesn't spam
        if math.floor(now) % 3 == 0 then
            console.print(string.format("[CoA Main] good_for_coa=true | since_last=%.1fs | flag=%s", 
                time_since_last_ancients, tostring(ancients_used_this_engagement)))
        end
    end

    -- ============================================
    -- TEMPORARY: Real buff detection (2506505 + string matching) is DISABLED.
    -- It was producing false positives and blocking valid casts (or causing hangs when debug was on).
    -- Current protection relies on:
    --   - ancients_summon_active_until (5s timer started on successful cast)
    --   - 7s hard minimum time gate
    --   - ancients_used_this_engagement sticky flag
    --   - 300s internal throttle in the spell file
    --   - Disengage timer (controlled by your "Minimum Time Between CoA" slider)
    -- ============================================

    local has_coa_passive = false

    -- Timer-based protection (5s summon duration - main short-term protection against re-casting while Ancients are active)
    if now < ancients_summon_active_until then
        has_coa_passive = true
    end

    -- Note: We deliberately do NOT call has_ancients_buff() here right now
    -- because the current ID/string logic was unreliable.

    if has_coa_passive then
        ancients_used_this_engagement = true
        console.print("[CoA] Blocking because summon timer still active (5s protection)")
    end

    -- Hard floor: never allow another CoA this soon after the previous one.
    -- Lowered to 7s (very aggressive) because the 5s summon timer is now the main protection against casting while Ancients are up.
    if time_since_last_ancients < 7 then
        if coa_debug and good_for_coa then
            console.print(string.format("[CoA] Not casting - still within 7s hard floor (since_last=%.1fs)", time_since_last_ancients))
        end
    elseif good_for_coa and not ancients_used_this_engagement and not has_coa_passive then
        if spells.call_of_the_ancients and spells.call_of_the_ancients.logics() then
            ancients_used_this_engagement = true
            last_ancients_cast_time = now
            last_boss_ancients_cast_time = now
            ancients_summon_active_until = now + 5.0   -- reduced to 5s as requested
            cast_end_time = now + 2.5
            console.print("[CoA] Successfully cast via main gate")
            return
        end
    elseif good_for_coa and coa_debug then
        -- Helpful debug so you can see exactly why it's not offering when good_for_coa=true
        local reason = ""
        if ancients_used_this_engagement then reason = reason .. "flag still set; " end
        if has_coa_passive then reason = reason .. "summon timer active; " end
        if time_since_last_ancients < 7 then reason = reason .. "under 7s floor; " end
        console.print("[CoA] good_for_coa=true but blocked: " .. reason .. "since_last=" .. string.format("%.1f", time_since_last_ancients))
    end

    -- ============================================
    -- Wrath of the Berserker - Advanced Adaptive Logic (No CoA)
    -- Rating is reactive but tuned to make *high* aggression levels harder to reach.
    -- Includes continuous idle decay so aggression slowly drops while sitting with no new elites.
    -- This rewards sustained speed and makes the tracker feel alive during idle periods.
    --   • Rebalanced weights, capped acceleration, high-end dampener.
    -- Death Boost + slowdown detection still work as before.
    -- ============================================
    if spells.wrath_of_the_berserk then
        local time_since_wrath = now - last_wrath_cast_time

        local in_pit = current_zone and string.lower(current_zone):find("pit") ~= nil

        -- === Calculate Clear Speed Rating (enhanced reactive version) ===
        -- Note: rolling/average data is primarily Pit-driven (elite tracking happens in Pit block above).
        -- Outside Pit we deliberately use low rating to be more willing on elites.
        -- Use helper for rolling count so it's always accurate (no reliance on prune timing).
        local rolling_count = count_elite_encounters_in_window(recent_elite_encounters, now, WRATH_ROLLING_WINDOW)
        local rolling_speed = rolling_count / (WRATH_ROLLING_WINDOW / 60)
        local run_duration = (pit_start_time > 0) and (now - pit_start_time) or 1

        -- Same floor as the display tracker so decisions aren't skewed by tiny early-run durations
        local effective_seconds = math.max(run_duration, WRATH_MIN_AVG_DURATION)
        local average_speed = (pit_elites_encountered > 0) and (pit_elites_encountered / (effective_seconds / 60)) or 0

        -- Short-term pace for fast reaction to "I'm slowing down"
        local short_count = count_elite_encounters_in_window(recent_elite_encounters, now, WRATH_SHORT_WINDOW)
        local short_speed = short_count / (WRATH_SHORT_WINDOW / 60)

        -- Same improved formula as the display tracker, with rebalancing to make high aggression harder to reach.
        -- This rewards sustained speed over short bursts (see comments in the display tracker block).
        local base_rating = (rolling_speed * 0.50) + (short_speed * 0.30) + (average_speed * 0.20)

        local trend = 1.0
        if rolling_speed > 0.1 and short_speed > 0.05 then
            local ratio = short_speed / rolling_speed
            if ratio < 0.55 then
                trend = 0.60
            elseif ratio < 0.78 then
                trend = 0.78
            elseif ratio > 1.80 then
                trend = 1.20
            elseif ratio > 1.45 then
                trend = 1.08
            end
        end

        local clear_speed_rating = base_rating * trend

        -- Extra "stuck on current elites" pressure (same logic as display tracker).
        -- If no new elite discovered for 35-55s+ while in Pit, force aggression down so Wrath actually gets used on the elites you're currently dealing with.
        if in_pit then
            if (now - last_new_elite_time) > 55 then
                clear_speed_rating = clear_speed_rating * 0.68
            elseif (now - last_new_elite_time) > 35 then
                clear_speed_rating = clear_speed_rating * 0.82
            end
        end

        -- Death aggression boost (same as display tracker): each death makes us more aggressive with Wrath this Pit run.
        if in_pit and pit_death_count > 0 then
            local death_reduction = math.min(pit_death_count * 0.15, 0.60)
            clear_speed_rating = clear_speed_rating * (1 - death_reduction)
        end

        -- Continuous idle decay (same as display tracker): while sitting with no new elites,
        -- aggression slowly drops over time so the tracker feels responsive during idle.
        local time_since_last_elite = now - last_new_elite_time
        if time_since_last_elite > 5 then
            local idle_factor = math.max(0.35, 1.0 - (time_since_last_elite - 5) * 0.006)
            clear_speed_rating = clear_speed_rating * idle_factor
        end

        -- Gentle high-end dampener (same as display tracker).
        -- Makes very high aggression (4.0+) require sustained excellent performance instead of bursts.
        if clear_speed_rating > 2.8 then
            local excess = clear_speed_rating - 2.8
            clear_speed_rating = 2.8 + (excess * 0.65)
        end

        -- Very wide clamps (0.10 = crawling/stuck → spend Wrath freely | 7.0 = blasting → extremely picky, save hard for boss)
        if clear_speed_rating < 0.10 then clear_speed_rating = 0.10 end
        if clear_speed_rating > 7.0 then clear_speed_rating = 7.0 end

        -- === Effective rating for decisions (context aware) ===
        local effective_rating = clear_speed_rating
        if not in_pit then
            effective_rating = 0.55   -- Force "slow / very willing on elites" mode outside Pit
        end

        -- === Dynamic Threshold ===
        -- Inverted logic per user request:
        -- Fast clear (high rating) → higher threshold → more picky, saves for boss
        -- Slow clear (low rating)  → lower threshold → more willing to use on elites
        local base_threshold = 55
        local dynamic_threshold = base_threshold * effective_rating   -- Faster clear = higher threshold = more picky

        -- Boss pressure makes us more conservative on elites (Pit only - outside Pit we want to use on good elites freely)
        local time_since_boss = now - last_boss_seen_time
        if in_pit and time_since_boss < 90 then
            dynamic_threshold = dynamic_threshold + 18   -- Quite a bit more conservative
        elseif in_pit and time_since_boss < 180 then
            dynamic_threshold = dynamic_threshold + 8
        end

        -- === Calculate current pack value ===
        local pack_value = 0

        if ts_data.has_boss then
            pack_value = 100   -- Bosses are always extremely high value
        else
            -- Elite pack scoring
            pack_value = elite_near * 22

            -- Bonus for very dense packs
            if elite_near >= 4 then
                pack_value = pack_value + 18
            end

            -- Fury starvation bonus (Wrath is excellent when dry)
            if fury_pct < 35 then
                pack_value = pack_value + 25
            elseif fury_pct < 50 then
                pack_value = pack_value + 12
            end

            -- Defensive value (use when in danger)
            if hp_pct < 45 then
                pack_value = pack_value + 20
            end
        end

        -- === Final Decision ===
        local should_cast_wrath = false
        local debug_reason = ""
        local boss_focus = wrath_boss_focus:get()
        local death_boost_triggered_this_cast = false  -- used to consume/reset the death boost after a successful Wrath cast caused by deaths

        if ts_data.has_boss then
            should_cast_wrath = true
            debug_reason = "Boss present"
        elseif not in_pit then
            -- OUTSIDE THE PIT: Be significantly more aggressive on elites.
            -- Lower bar, still respects boss_focus but relaxes it. Good single elites + fury/defensive bonuses are now valid.
            local outside_threshold = dynamic_threshold * 0.55   -- much lower bar for non-Pit content
            local relaxed_focus_penalty = boss_focus and 25 or 0

            if pack_value >= (outside_threshold + relaxed_focus_penalty) then
                should_cast_wrath = true
                debug_reason = string.format("Outside Pit - aggressive on elites (value %.0f >= %.0f)", pack_value, outside_threshold + relaxed_focus_penalty)
            elseif elite_near >= 2 then
                -- 2+ elites outside Pit is almost always worth popping Wrath (big AoE + fury + movespeed)
                should_cast_wrath = true
                debug_reason = string.format("Outside Pit - 2+ elites (near=%d, value %.0f)", elite_near, pack_value)
            elseif elite_near >= 1 and (fury_pct < 45 or hp_pct < 50) then
                -- Single strong elite + need fury or defensives outside Pit
                should_cast_wrath = true
                debug_reason = string.format("Outside Pit - priority single elite (fury/hp bonus, value %.0f)", pack_value)
            else
                debug_reason = string.format("Outside Pit - elite pack not worth (value %.0f < %.0f)", pack_value, outside_threshold)
            end
        elseif boss_focus then
            -- Boss Focus Mode: Very conservative on elites (Pit only)
            -- Death boost relaxes this — the more you've died, the less strict we are
            local bf_extra = 45 - (pit_death_count * 10)
            bf_extra = math.max(bf_extra, 5)
            local bf_min_elites = math.max(2, 4 - pit_death_count)
            if pack_value >= (dynamic_threshold + bf_extra) and elite_near >= bf_min_elites then
                should_cast_wrath = true
                if pit_death_count > 0 then
                    death_boost_triggered_this_cast = true
                end
                debug_reason = string.format("Exceptional elite pack in Boss Focus (death boost relaxed, value %.0f)", pack_value)
            else
                debug_reason = "Boss Focus Mode - Saving for boss"
            end
        elseif pack_value >= dynamic_threshold then
            should_cast_wrath = true
            debug_reason = string.format("Good elite pack (value %.0f >= threshold %.0f)", pack_value, dynamic_threshold)
        else
            debug_reason = string.format("Elite pack not worth it (value %.0f < threshold %.0f | speed=%.2f)", 
                pack_value, dynamic_threshold, clear_speed_rating)
        end

        -- === DEATH BOOST OVERRIDE (strongest effect) ===
        -- When you've died multiple times in this Pit, we deliberately become much more aggressive with Wrath on elites
        -- to help you recover. This bypasses normal pack_value thresholds and boss_focus strictness.
        if in_pit and pit_death_count > 0 and not ts_data.has_boss and not should_cast_wrath then
            local min_elites = math.max(1, 3 - pit_death_count)   -- 3+ deaths → even single elites are worth it
            if elite_near >= min_elites then
                should_cast_wrath = true
                death_boost_triggered_this_cast = true
                debug_reason = string.format("DEATH BOOST OVERRIDE (%d deaths) - forcing on %d nearby elite(s) to recover", pit_death_count, elite_near)
            end
        end

        -- Debug output when we consider casting (or reject)
        -- When death boost is active we print more often so you can see why it's (or isn't) offering Wrath
        local force_debug_due_to_deaths = pit_death_count > 0 and elite_near >= 1
        if has_priority and (ts_data.has_boss or elite_near >= 2 or force_debug_due_to_deaths) then
            local focus_tag = boss_focus and " [BOSS FOCUS]" or ""
            local context = in_pit and " [PIT]" or " [OPEN]"
            local death_tag = pit_death_count > 0 and string.format(" [DEATHS:%d]", pit_death_count) or ""
            console.print(string.format("[Wrath] Value=%.0f | Threshold=%.0f | Speed=%.2f%s%s%s | SinceLast=%.0fs | %s", 
                pack_value, dynamic_threshold, clear_speed_rating, context, focus_tag, death_tag, time_since_wrath, debug_reason))
        end

        if should_cast_wrath then
            local cast_success = spells.wrath_of_the_berserk.logics()
            if cast_success then
                last_wrath_cast_time = now
                cast_end_time = now + 0.25
                local cast_context = in_pit and "Pit" or "Open World"
                console.print(string.format("[Wrath] CASTED [%s] - Rating: %.2f (Rolling: %.1f/min, Avg: %.1f/min)", 
                    cast_context, clear_speed_rating, rolling_speed, average_speed))

                -- Consume the death boost after a successful cast that was triggered/influenced by deaths.
                -- This prevents the boost from staying permanently maxed out for the rest of the Pit.
                if death_boost_triggered_this_cast or (in_pit and pit_death_count > 0) then
                    console.print("[Wrath] Death Boost consumed - death aggression counter has been reset.")
                    pit_death_count = 0
                    last_pit_death_count = 0
                end

                return
            else
                -- Helpful feedback especially when death boost is active
                if death_boost_triggered_this_cast or pit_death_count > 0 or string.find(debug_reason or "", "DEATH BOOST") then
                    console.print(string.format("[Wrath][DEATH BOOST] We wanted to cast (reason: %s) but the spell's logics() rejected it.", debug_reason or "unknown"))
                    console.print("[Wrath][DEATH BOOST] Possible blockers: low fury, spell on cooldown (25s internal safety), your spell menu 'Filter Mode' + 'Min Enemies Around', or orbwalker mode.")
                end
            end
        end
    end

    local profile_name = build_profile_options[build_profile:get() + 1] or "Wrath of the Berserker"
    local profile = build_profiles.get and build_profiles.get(profile_name) or {}

    local in_burst = false
    if burst_window_mode:get() and has_priority then
        if (now - last_ancients_cast_time) < burst_window_duration:get() then in_burst = true end
        if (now - last_wrath_cast_time) < 10.0 then in_burst = true end
        if elite_near >= burst_min_elites:get() then in_burst = true end
        if burst_on_boss:get() and ts_data.has_boss then in_burst = true end
    end

    -- War Cry
    if has_priority and spells.war_cry and spells.war_cry.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Challenging Shout
    if has_priority and spells.challenging_shout and spells.challenging_shout.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Rallying Cry
    -- No longer gated behind has_priority so it can upkeep the buff when there are no elites
    -- (it will still prefer elites when they are present via its own logic)
    if spells.rallying_cry and spells.rallying_cry.logics() then
        cast_end_time = now + 0.15
        return
    end

    -- Iron Skin 24/7
    if maintain_resolve_defensives:get() and spells.iron_skin and spells.iron_skin.logics() then
        cast_end_time = now + 0.2
        return
    end



    -- Burst Combo
    local do_combo = false
    if elite_boss_burst_combo:get() and has_priority then
        do_combo = not burst_combo_requires_boss_or_multi:get() or ts_data.has_boss or elite_near >= 2
    end
    if do_combo then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = now + 0.08 end
        if (burst_combo_requires_boss_or_multi:get() or ts_data.has_boss) and spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = now + 0.08 end
        if spells.war_cry and spells.war_cry.logics() then cast_end_time = now + 0.08 end
        if cast_end_time > now then return end
    end

    -- Low HP defensives
    if hp_pct < health_threshold:get() then
        if spells.iron_skin and spells.iron_skin.logics() then cast_end_time = now + 0.25; return end
        if spells.challenging_shout and spells.challenging_shout.logics() then cast_end_time = now + 0.2; return end
    end

    -- Whirlwind (hardcoded defaults after removing the menu section to fix crashes)
    local want_ww = false
    local ww_fury_threshold = 28
    local whirlwind_burst_elite = true
    local ww_min_enemies = 2
    local good_fury = fury_pct >= (ww_fury_threshold / 100)
    if (whirlwind_burst_elite or (profile.constant_ww_priority)) and has_priority and good_fury then
        want_ww = true
    elseif close_count >= ww_min_enemies and good_fury then
        want_ww = true
    end
    if in_burst and good_fury then want_ww = true end

    if want_ww and spells.whirl_wind and spells.whirl_wind.logics(best) then
        cast_end_time = now + 0.28
        return
    end

    -- Smart Ground Stomp
    if smart_ground_stomp:get() and close_count >= ground_stomp_min_enemies:get() then
        if spells.ground_stomp and spells.ground_stomp.logics(best) then
            cast_end_time = now + 0.3
            return
        end
    end

    -- Steel Grasp
    if has_priority and steel_grasp_on_elites:get() then
        if spells.steel_grasp and spells.steel_grasp.logics(entities, ts_data, best) then
            cast_end_time = now + 0.2
            return
        end
    end

    -- Generators
    local lunging_fury_limit = 32   -- hardcoded default (was previously in removed Whirlwind menu)
    if fury_pct < (lunging_fury_limit / 100) then
        local pref = profile.preferred_generator or "lunging_strike"
        if spells[pref] and spells[pref].logics(entities) then cast_end_time = now + 0.15; return end
        for _, gen in ipairs(profile.secondary_generators or {"lunging_strike","bash","flay","frenzy"}) do
            if spells[gen] and spells[gen].logics(entities) then cast_end_time = now + 0.15; return end
        end
    end

    -- Finishers
    if use_finishers_on_elites:get() and has_priority and best:get_current_health() / best:get_max_health() < 0.35 then
        if spells.rupture and spells.rupture.logics(best) then cast_end_time = now + 0.6; return end
        if spells.death_blow and spells.death_blow.logics(best) then cast_end_time = now + 0.3; return end
    end

    if spells.lunging_strike and spells.lunging_strike.logics(entities) then cast_end_time = now + 0.12; return end
    if spells.bash and spells.bash.logics(entities) then cast_end_time = now + 0.1; return end
end)

on_render(function()
    if not menu.main_boolean:get() then return end
    local p = get_local_player()
    if not p then return end

    -- Wrath Clear Speed Display - moved up so it shows 24/7 regardless of current target
    if show_wrath_speed_display:get() then
        local world = world.get_current_world()
        local current_zone = world and world:get_current_zone_name() or ""

        local y = 80
        graphics.text_2d("Wrath of the Berserker - Clear Speed Tracker", vec2:new(10, y), 15, color_yellow(255))
        y = y + 18

        local is_in_pit = string.lower(current_zone or ""):find("pit")

        local disp_rolling    = is_in_pit and wrath_rolling_speed   or last_wrath_rolling_speed
        local disp_average    = is_in_pit and wrath_average_speed   or last_wrath_average_speed
        local disp_aggression = is_in_pit and wrath_clear_speed_rating or last_wrath_clear_speed_rating

        graphics.text_2d(string.format("Recent (last 3 min): %.1f elites/min", disp_rolling), vec2:new(10, y), 14, color_white(220))
        y = y + 16
        graphics.text_2d(string.format("This Pit Run Average: %.1f elites/min", disp_average), vec2:new(10, y), 14, color_white(220))
        y = y + 16
        graphics.text_2d(string.format("Current Aggression: %.2fx", disp_aggression), vec2:new(10, y), 14, color_white(220))
        y = y + 16

        local disp_elites = is_in_pit and pit_elites_encountered or last_pit_elites_encountered
        graphics.text_2d("Elites This Run: " .. disp_elites, vec2:new(10, y), 14, color_white(220))
        y = y + 16

        -- Death aggression boost display
        local active_deaths = is_in_pit and pit_death_count or last_pit_death_count
        if active_deaths > 0 then
            local boost_pct = math.floor(active_deaths * 15)
            graphics.text_2d(string.format("Death Boost: +%d%% more aggressive with Wrath (%d deaths)", boost_pct, active_deaths), vec2:new(10, y), 13, color_red(220))
            y = y + 16
        end

        local focus_text = wrath_boss_focus:get() and " [BOSS FOCUS]" or ""
        if is_in_pit then
            graphics.text_2d("Status: Live - Current Pit run" .. focus_text, vec2:new(10, y), 12, color_green(200))
        else
            graphics.text_2d("Status: Last completed Pit (values kept)" .. focus_text, vec2:new(10, y), 12, color_white(180))
        end
        y = y + 14
        graphics.text_2d("(Higher = more picky / saves for boss | Lower = more willing on elites)", vec2:new(10, y), 11, color_white(160))
        y = y + 13
        graphics.text_2d("Aggression slowly decays while idle with no new elites (continuous idle decay). High values require sustained speed.", vec2:new(10, y), 10, color_white(140))
    end

    local selected = my_target_selector.get_current_selected_position()
    local ts = my_target_selector.get_target_selector_data(selected, my_target_selector.get_target_list(selected, 16, {false,2}, {true,5}, {false,90}))
    if not ts.is_valid then return end

    local target = ts.closest_unit
    if ts.has_boss then target = ts.closest_boss
    elseif ts.has_elite then target = ts.closest_elite end

    if target then
        local tpos = target:get_position()
        local ppos = p:get_position()
        local t2d = graphics.w2s(tpos)
        local p2d = graphics.w2s(ppos)
        if not t2d:is_zero() and not p2d:is_zero() then
            graphics.line(t2d, p2d, color_red(180), 2.5)
            graphics.circle_3d(tpos, 0.8, color_red(200), 2)
        end
    end
end)

console.print("[V1per Barb]")