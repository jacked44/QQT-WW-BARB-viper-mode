-- build_profiles.lua
-- Modern, data-driven build profiles for the Barbarian rotation.
-- Each profile defines behavior, priorities, and thresholds.
-- This is a core part of making the rotation "modern" like advanced Necro setups.

local build_profiles = {}

build_profiles.PROFILES = {
    ["Wrath of the Berserker"] = {
        name = "Wrath of the Berserker",
        short = "Wrath",
        description = "Heavy custom Wrath of the Berserker adaptive rotation with death boost, idle decay, and strong elite pressure.",

        primary_spender = "whirl_wind",
        preferred_generator = "lunging_strike",
        secondary_generators = {"bash", "flay", "frenzy"},

        fury_for_spender = 0.30,
        fury_for_generator = 0.35,

        shout_order = {"war_cry", "rallying_cry", "challenging_shout"},
        burst_spenders = {"hammer_of_ancients", "upheaval", "double_swing", "rend"},

        constant_ww_priority = false,   -- Wrath adaptive logic controls most burst decisions
        aggressive_ancients = false,    -- CoA is deprioritized in this profile
    },

    ["Call of the Ancients"] = {
        name = "Call of the Ancients",
        short = "CoA",
        description = "CoA (Call of the Ancients) focused burst rotation with strong single-cast protection and pack engagement logic.",

        primary_spender = "whirl_wind",
        preferred_generator = "lunging_strike",
        secondary_generators = {"bash", "flay"},

        fury_for_spender = 0.35,
        fury_for_generator = 0.28,

        shout_order = {"war_cry", "rallying_cry", "challenging_shout"},
        burst_spenders = {"hammer_of_ancients", "upheaval"},

        constant_ww_priority = false,
        aggressive_ancients = true,
        ancients_is_top_priority = true,
    },
}

function build_profiles.get(name)
    return build_profiles.PROFILES[name] or build_profiles.PROFILES["Wrath of the Berserker"]
end

function build_profiles.get_names()
    local names = {}
    for k, _ in pairs(build_profiles.PROFILES) do
        table.insert(names, k)
    end
    return names
end

-- Helper: Get recommended fury thresholds for current profile
function build_profiles.get_fury_thresholds(profile)
    profile = profile or build_profiles.get("Wrath of the Berserker")
    return {
        spender = profile.fury_for_spender or 0.65,
        generator = profile.fury_for_generator or 0.32
    }
end

return build_profiles