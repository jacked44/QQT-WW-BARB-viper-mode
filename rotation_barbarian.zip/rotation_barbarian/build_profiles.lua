-- build_profiles.lua
-- Modern, data-driven build profiles for the Barbarian rotation.
-- Each profile defines behavior, priorities, and thresholds.
-- This is a core part of making the rotation "modern" like advanced Necro setups.

local build_profiles = {}

build_profiles.PROFILES = {
    ["WW Spin (Meta)"] = {
        name = "WW Spin (Meta)",
        short = "WW",
        description = "Dust Devil Whirlwind focused. Maximize spin uptime with smart generators.",

        -- Core behavior
        primary_spender = "whirl_wind",
        preferred_generator = "lunging_strike",
        secondary_generators = {"bash", "flay", "frenzy"},

        -- Fury thresholds (aggressive WW style)
        fury_for_spender = 0.28,
        fury_for_generator = 0.38,

        -- Priorities
        shout_order = {"war_cry", "rallying_cry", "challenging_shout"},
        burst_spenders = {"hammer_of_ancients", "upheaval", "double_swing", "rend"},

        -- Special behaviors
        constant_ww_priority = true,
        aggressive_ancients = true,
        use_mobility_on_elites = true,

        -- Burst settings
        burst_min_elites = 2,
        ancients_window_duration = 10,
    },

    ["Minion Ancients Burst (Meta)"] = {
        name = "Minion Ancients Burst (Meta)",
        short = "Minion",
        description = "Heavy Call of the Ancients focus with burst windows.",

        primary_spender = "whirl_wind",
        preferred_generator = "lunging_strike",
        secondary_generators = {"bash", "flay"},

        fury_for_spender = 0.32,
        fury_for_generator = 0.30,

        shout_order = {"war_cry", "rallying_cry", "challenging_shout"},
        burst_spenders = {"hammer_of_ancients", "upheaval"},

        constant_ww_priority = true,
        aggressive_ancients = true,
        ancients_is_top_priority = true,

        burst_min_elites = 1,
        ancients_window_duration = 12,
    },

    ["HoTA Focused"] = {
        name = "HoTA Focused",
        short = "HoTA",
        description = "Hammer of the Ancients build. Big damage on grouped targets.",

        primary_spender = "hammer_of_ancients",
        preferred_generator = "lunging_strike",
        secondary_generators = {"bash", "double_swing"},

        fury_for_spender = 0.72,
        fury_for_generator = 0.25,

        shout_order = {"war_cry", "rallying_cry", "challenging_shout"},
        burst_spenders = {"hammer_of_ancients", "upheaval"},

        constant_ww_priority = false,
        aggressive_ancients = true,

        burst_min_elites = 3,
    },

    ["Balanced Hybrid"] = {
        name = "Balanced Hybrid",
        short = "Hybrid",
        description = "Flexible profile that adapts between WW and big spenders.",

        primary_spender = "whirl_wind",
        preferred_generator = "lunging_strike",
        secondary_generators = {"bash", "flay", "frenzy"},

        fury_for_spender = 0.65,
        fury_for_generator = 0.32,

        shout_order = {"war_cry", "rallying_cry", "challenging_shout"},
        burst_spenders = {"hammer_of_ancients", "upheaval", "double_swing", "rend"},

        constant_ww_priority = true,
        aggressive_ancients = true,

        burst_min_elites = 2,

        -- Mobility preference for WW-style flexibility
        mobility_style = "smart_interchange",  -- lunging_first, leap_first, or smart_interchange
    },
}

function build_profiles.get(name)
    return build_profiles.PROFILES[name] or build_profiles.PROFILES["Balanced Hybrid"]
end

function build_profiles.get_names()
    local names = {}
    for k, _ in pairs(build_profiles.PROFILES) do
        table.insert(names, k)
    end
    return names
end

-- Helper: Get recommended fury thresholds for current profile
function build_profiles.get_fury_thresholds(profile)
    profile = profile or build_profiles.get("Balanced Hybrid")
    return {
        spender = profile.fury_for_spender or 0.65,
        generator = profile.fury_for_generator or 0.32
    }
end

return build_profiles