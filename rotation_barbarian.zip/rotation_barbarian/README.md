# Barbarian Rotation - V1per Mode

A powerful, profile-driven Barbarian rotation for QQT (Diablo 4) focused on current meta builds. It is fully aware of your equipped skills and intelligently prioritizes elites, champions, and bosses while using strong anti-spam logic on major cooldowns like Call of the Ancients.

**Written and maintained by me (V1per).** I built this rotation to feel exactly how I want to play Barbarian in Season 13+.

---

## Recent Changes I Made

I spent a lot of time refining this rotation based on actual gameplay. Here's everything I added and fixed:

- **Elite/Boss Burst Combo** (the big one you just asked for): Added a dedicated system that tries to fire **Iron Skin + Challenging Shout + War Cry back-to-back in the same tick** the moment an elite or boss appears. This makes the three skills land as a true coordinated burst with maximum buff overlap instead of firing randomly at different times. I added menu options for it (including a stricter "only on boss or 2+ elites" mode) and suppressed the old trash usage of these skills when the combo is enabled so they are saved for big targets. Order is Iron Skin → Challenging Shout → War Cry for best defensive → utility → damage layering.

- Added a proper **class guard** at the very top so the script only loads on Barbarian (class ID 1). No more loading on other characters.
- Completely reworked **Call of the Ancients** logic multiple times until it was perfect. It now casts only **once per boss encounter** (with a dedicated long lock) and has much smarter anti-spam for elites. I added separate boss tracking and a "Group Lockout" slider.
- Reorganized the **entire menu** into clean collapsible sections (Call of the Ancients, Whirlwind Settings, Defensives & Mobility, Burst Window, Shouts & Finishers, Debug) so everything is organized like Targeting Mode and Select Spell.
- Simplified to only two Build Profiles: "Wrath of the Berserker" (current custom Wrath adaptive + death boost rotation) and "Call of the Ancients" (CoA focused burst). All older profiles removed.
- Rebuilt the **Select Spell** system from the ground up to match my desktop `rotation_barbarian` exactly. Every spell now has its own "Enable Spell" toggle plus all the relevant options (min enemies, off cooldown, filters, etc.). When you pick a spell from the dropdown, all its settings appear right below it.
- Added proper **Rallying Cry** behavior: casts once when you encounter elites/bosses, then upkeeps every 7 seconds or when the buff drops (while still respecting the Min Enemies slider). I had to make the calls unconditional so it works while spinning on trash.
- Added **"Use Off Cooldown 24/7"** checkboxes for both Challenging Shout and Iron Skin. These now actually work because I added unconditional calls for them in the priority logic.
- Fixed **player targeting mode** so it properly targets the closest enemy to your character (without breaking cursor targeting).
- Implemented full **auto skill detection**. The rotation now automatically detects when you swap skills and uses them properly. I first added a periodic refresh + a working "Force Refresh Equipped Skills" button (with proper rising-edge logic so it never hides my other menus). Later I simplified it to the clean sorcerer-style system (static full load + relying on the game's `is_spell_ready`) so it's even more reliable with zero extra button hassle.


All of these changes were driven by me actually playing the rotation and saying "this still isn't right" until it felt good.

---

## Current State

This rotation is now very stable. The auto skill detection "just works", all the off-cooldown shout/defensive toggles function properly, Call of the Ancients doesn't spam, and the menu is clean and organized.

### Supported Playstyles
- **Wrath of the Berserker** — Current custom Wrath adaptive rotation (death boost, idle decay, Temis reset, etc.)
- **Call of the Ancients** — CoA focused burst rotation with strong single-cast protection

This rotation is designed to feel strong in both speed farming and high-tier pushing content.

## For QQT Diablo (Diablo 4 Lua Loader)

This is a highly customized Barbarian rotation focused on the current meta (Season 13+ 2026):

- **S-Tier: Whirlwind "Spin to Win"** (Dust Devils, constant clear, Resolve tankiness)
- **S-Tier: Minion Ancients / Call of the Ancients burst** playstyle

### What I Focused On While Building This
- Build Profile selector with real adaptability on the non-meta profiles (WW Spin Meta left untouched)
- Extremely strong anti-spam + once-per-boss-encounter logic on Call of the Ancients
- Full Rallying Cry upkeep (encounter + 7s / buff drop) + working 24/7 off-cooldown for Challenging Shout and Iron Skin
- Clean, organized menu with proper collapsible tree sections
- Select Spell system that works exactly like my desktop reference (Enable toggles + full per-spell options)
- Reliable auto skill detection (simplified to sorcerer style) so skill swaps just work
- Whirlwind travel when block orbwalker movement is enabled
- Countless small fixes from real gameplay testing (targeting, unconditional calls, menu behavior, etc.)

### Recommended Settings (Meta)
- **Build Profile**: "Wrath of the Berserker" for the current Wrath setup, or "Call of the Ancients" for CoA burst
- WW Fury Threshold: 25-32%
- Enable "Aggressive Shouts" and "Maintain Resolve Defensives"
- Steel Grasp on Elites: On
- Smart Ground Stomp: On (great for keeping WW hitting max targets)

### Shout Behavior (Important)
Rallying Cry, War Cry, and Challenging Shout now have smart "buff remaining time" checks.
They will **only** attempt to cast when:
- The actual buff has worn off or has < ~3 seconds left, **AND**
- Your chosen filter + "Min Enemies Around" condition is met.

This prevents the previous spam. Set "Min Enemies Around" to 3 (as you have) + "No filter" and it will only refresh the buff when it expires on packs of 3+. 

If you want shouts **only on elites**, change the Filter Mode in each shout's submenu to "Elite & Boss Only".

### Call of the Ancients Behavior (Strong Anti-Spam)
Call of the Ancients is heavily protected against spamming — it is designed to be used **once per meaningful group/engagement**, not on every single elite or boss you see.

**Multiple layers of protection (it will NOT spam on every elite/boss):**
- **Group Lockout** ("Ancients Group Lockout (sec)" slider, default **25s**): After casting, the script refuses to cast again until you have gone a long time with **literally zero** elites or bosses visible. A whole pack, wave, or area counts as one group.
- Hard absolute minimum 30 seconds between any two casts.
- Profile cooldown (38s Minion / 45s normal).
- Spell's own 60s safety timer + game `is_spell_ready()` check.

**Practical result**: You will very rarely (if ever) see it waste the skill on a lone elite or small scattered bosses. It waits for a real engagement or a new area after you've been clear.

Recommended slider: 20–35s (higher = more conservative "once per big pull" behavior).

It fully respects the Filter Mode + Min Enemies you set in the Call of the Ancients submenu (dropdown). "Elite & Boss Only" is highly recommended.

### Burst Window Mode (Elites & Bosses)
When **Burst Window Mode** is enabled, the script now uses smart detection focused on elites and bosses:

- Post-Ancients burst window (tunable duration)
- Post-Wrath of the Berserk window
- Automatic burst when 2+ elites are present
- Always burst on bosses (toggle)

During these windows the rotation becomes much more aggressive with spenders (HoTA, Upheaval, Double Swing, Rend) and mobility — but **only** on elites/bosses.

Tune with:
- "Burst Window Duration (sec)" → 8–12 is usually ideal
- "Auto-Burst on X+ Elites" → 2 is a good sweet spot
- "Always Burst on Boss" → Keep enabled

This prevents wasting big cooldowns on trash while dumping everything during real elite/boss engagements.

- After you cast it on a pack of elites/bosses, it will **not** cast again for that group even if more elites spawn or the fight drags on.
- It only becomes available again after you have gone the full lockout duration with **zero** elites or bosses visible.
- Recommended: 15–30 seconds depending on how dense the content is.
- It still respects the build profile cooldown (38s for Minion profile, 45s otherwise) and the spell's own safety timer + `is_spell_ready`.

Use the dropdown to open the Call of the Ancients spell submenu and set Filter Mode to "Elite & Boss Only" for best results.

### How to Use
1. Place the entire `rotation_barbarian` folder in your QQT `scripts/` directory.
2. Reload with **F5** in game.
3. Open menu with the in-game overlay (usually the plugin tree).
4. Enable + configure per-spell submenus via the dropdown if needed.
5. Recommended: Use with orbwalker in **Clear** mode.
6. If you use any script/utility that calls `orbwalker.set_block_movement(true)`, the rotation will automatically use Whirlwind to travel (spin-to-move) instead of walking.

### QQT Coding Notes (for future edits)
- Always respect `my_utility.is_action_allowed()` (evade, mount, blood mist, etc.)
- WW uses special `add_channel_spell` + continuous `update_channel_spell_position`
- Per-spell `logics()` already handle ready/affordable/menu checks via `is_spell_allowed`
- Use `get_time_since_inject()` for all timers
- Target selection prefers elites > bosses > champs > normal (within range)

### Resources
- QQT Discord: https://discord.gg/VE2gztW23q
- Lua API Wiki: https://github.com/qqtnn/diablo_lua_documentation/wiki
- Official rotations & updates: https://github.com/qqtnn/qqt_diablo

**Warning**: This is automation software for Diablo 4. Use at your own risk. Blizzard actively bans bot users.

This is my personal Barbarian rotation. I update it whenever something feels off during actual gameplay.