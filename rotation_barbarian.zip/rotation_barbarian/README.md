# Barbarian Rotation - V1per Dynamic (Equipped Skills Aware)

A powerful, profile-driven Barbarian rotation for QQT (Diablo 4) focused on current meta builds. It is fully aware of your equipped skills and intelligently prioritizes elites, champions, and bosses while using strong anti-spam logic on major cooldowns like Call of the Ancients.

### Supported Playstyles
- **WW Spin (Meta)** — Dust Devil Whirlwind with constant uptime and elite bursting
- **Minion Ancients Burst (Meta)** — Call of the Ancients + Wrath focused burst windows
- **HoTA Focused** — Hammer of the Ancients spender playstyle
- **Balanced Hybrid** — Flexible mix of generators and spenders

This rotation is designed to feel strong in both speed farming and high-tier pushing content.

## For QQT Diablo (Diablo 4 Lua Loader)

This is a highly customized Barbarian rotation focused on the current meta (Season 13+ 2026):

- **S-Tier: Whirlwind "Spin to Win"** (Dust Devils, constant clear, Resolve tankiness)
- **S-Tier: Minion Ancients / Call of the Ancients burst** playstyle

### Key Improvements in v3.1
- Build Profile selector (WW Spin Meta / Minion Ancients Burst / HoTA / Hybrid)
- Completely restructured priority system (9 clear phases) aligned with Maxroll/Icy Veins meta
- Smarter Call of the Ancients tracking (no spam, profile-aware CD, boss priority)
- Aggressive shout uptime for damage/DR buffs (War Cry + Rallying Cry)
- Improved defensives (Iron Skin for Tibault's Will / Resolve procs even above low HP)
- Lunging Strike prioritized as best low-fury generator + gap closer
- Better WW conditions (fury, enemy count, elite burst, burst window synergy)
- Elite/Boss finishers (Rupture/Death Blow)
- Cleaner code, better comments, QQT API best practices followed

### Recommended Settings (Meta)
- **Build Profile**: "WW Spin (Meta)" for most content, or "Minion Ancients Burst (Meta)" for Pit pushing
- WW Fury Threshold: 25-32%
- Enable "Aggressive Shouts" and "Maintain Resolve Defensives"
- Steel Grasp on Elites: On
- Smart Ground Stomp: On (great for keeping WW hitting max targets)

### Shout Behavior (Important)
Rallying Cry, War Cry, and Challenging Shout now have smart "buff remaining time" checks.
They will **only** attempt to cast when:
- The actual buff has worn off or has < ~3 seconds left, **AND**
- Your chosen filter + "Min Enemies Around" condition is met.

This prevents the previous spam. Set "Min Enemies Around" to 3 (as you have) + "No filter" and it will only refresh the buff when it expires on packs of 3+. 

If you want shouts **only on elites**, change the Filter Mode in each shout's submenu to "Elite & Boss Only".

### Call of the Ancients Behavior (Strong Anti-Spam)
Call of the Ancients is heavily protected against spamming — it is designed to be used **once per meaningful group/engagement**, not on every single elite or boss you see.

**Multiple layers of protection (it will NOT spam on every elite/boss):**
- **Group Lockout** ("Ancients Group Lockout (sec)" slider, default **25s**): After casting, the script refuses to cast again until you have gone a long time with **literally zero** elites or bosses visible. A whole pack, wave, or area counts as one group.
- Hard absolute minimum 30 seconds between any two casts.
- Profile cooldown (38s Minion / 45s normal).
- Spell's own 60s safety timer + game `is_spell_ready()` check.

**Practical result**: You will very rarely (if ever) see it waste the skill on a lone elite or small scattered bosses. It waits for a real engagement or a new area after you've been clear.

Recommended slider: 20–35s (higher = more conservative "once per big pull" behavior).

It fully respects the Filter Mode + Min Enemies you set in the Call of the Ancients submenu (dropdown). "Elite & Boss Only" is highly recommended.

### Burst Window Mode (Elites & Bosses)
When **Burst Window Mode** is enabled, the script now uses smart detection focused on elites and bosses:

- Post-Ancients burst window (tunable duration)
- Post-Wrath of the Berserk window
- Automatic burst when 2+ elites are present
- Always burst on bosses (toggle)

During these windows the rotation becomes much more aggressive with spenders (HoTA, Upheaval, Double Swing, Rend) and mobility — but **only** on elites/bosses.

Tune with:
- "Burst Window Duration (sec)" → 8–12 is usually ideal
- "Auto-Burst on X+ Elites" → 2 is a good sweet spot
- "Always Burst on Boss" → Keep enabled

This prevents wasting big cooldowns on trash while dumping everything during real elite/boss engagements.

- After you cast it on a pack of elites/bosses, it will **not** cast again for that group even if more elites spawn or the fight drags on.
- It only becomes available again after you have gone the full lockout duration with **zero** elites or bosses visible.
- Recommended: 15–30 seconds depending on how dense the content is.
- It still respects the build profile cooldown (38s for Minion profile, 45s otherwise) and the spell's own safety timer + `is_spell_ready`.

Use the dropdown to open the Call of the Ancients spell submenu and set Filter Mode to "Elite & Boss Only" for best results.

### How to Use
1. Place the entire `rotation_barbarian` folder in your QQT `scripts/` directory.
2. Reload with **F5** in game.
3. Open menu with the in-game overlay (usually the plugin tree).
4. Enable + configure per-spell submenus via the dropdown if needed.
5. Recommended: Use with orbwalker in **Clear** mode.

### QQT Coding Notes (for future edits)
- Always respect `my_utility.is_action_allowed()` (evade, mount, blood mist, etc.)
- WW uses special `add_channel_spell` + continuous `update_channel_spell_position`
- Per-spell `logics()` already handle ready/affordable/menu checks via `is_spell_allowed`
- Use `get_time_since_inject()` for all timers
- Target selection prefers elites > bosses > champs > normal (within range)

### Resources
- QQT Discord: https://discord.gg/VE2gztW23q
- Lua API Wiki: https://github.com/qqtnn/diablo_lua_documentation/wiki
- Official rotations & updates: https://github.com/qqtnn/qqt_diablo

**Warning**: This is automation software for Diablo 4. Use at your own risk. Blizzard actively bans bot users.

Maintained/customized for V1per.