local my_utility = require("my_utility/my_utility")

local menu_elements_call_of_the_anc = {
    tree_tab = tree_node:new(1),
    main_boolean = checkbox:new(true, get_hash(my_utility.plugin_label .. "main_boolean_call_anc_base")),
    filter_mode = combo_box:new(0, get_hash(my_utility.plugin_label .. "call_anc_base_filter_mode")),
    min_max_targets = slider_int:new(0, 30, 5, get_hash(my_utility.plugin_label .. "min_max_number_of_targets_for_anc_base")),
    debug_buffs = checkbox:new(false, get_hash(my_utility.plugin_label .. "debug_coa_buffs_viper"))
}

local function menu()
    if menu_elements_call_of_the_anc.tree_tab:push("Call Of The Ancient") then
        menu_elements_call_of_the_anc.main_boolean:render("Enable Spell", "")
        if menu_elements_call_of_the_anc.main_boolean:get() then
            local dropbox_options = {"No filter", "Elites & Bosses Only (recommended for packs)", "Boss Only (best for bosses)"}
            menu_elements_call_of_the_anc.filter_mode:render("Filter Modes", dropbox_options, "")
            menu_elements_call_of_the_anc.min_max_targets:render("Min Enemies Around", "For Boss Only this is mostly ignored (any boss close is enough). For other filters it controls pack size.")
            menu_elements_call_of_the_anc.debug_buffs:render("Debug: Print CoA Buffs (enable while fighting elites)", "When on, prints every buff name + hash it sees. There's also a more visible version of this in the main 'Call of the Ancients' tree above.")
        end
        menu_elements_call_of_the_anc.tree_tab:pop()
    end
end

local next_time_allowed_cast = 0.0
local spell_id_ancient = 309802

-- Exact buff ID for the Call of the Ancients passive (the summon effect that indicates CoA is active).
-- While this buff is present on the player we must never cast CoA again.
local coa_passive_buff_id = 2506505

-- Returns true if the Call of the Ancients passive buff is currently active on the player.
-- When this buff is present, the Ancients are summoned and we must not cast CoA again.
-- This is the key gate to ensure CoA fires only once per elite/boss engagement.
local function has_call_of_the_ancients_buff()
    local player = get_local_player()
    if not player then return false end

    local debug_enabled = menu_elements_call_of_the_anc.debug_buffs:get()
    if not debug_enabled and _G.COA_DEBUG_BUFFS then
        debug_enabled = true
    end

    local buffs = player:get_buffs() or {}
    local found_match = false

    -- Throttle heavy debug printing so it doesn't feel like it's hanging / scanning forever.
    -- Full buff list only dumps occasionally when the debug checkbox is enabled.
    local should_dump = false
    if debug_enabled then
        local t = get_time_since_inject()
        if not _G.COA_LAST_FULL_DUMP or (t - _G.COA_LAST_FULL_DUMP) > 2.5 then
            _G.COA_LAST_FULL_DUMP = t
            should_dump = true
        end
    end

    for _, buff in ipairs(buffs) do
        local buff_name = ""
        if type(buff.name) == "function" then
            buff_name = buff:name() or ""
        end
        local name_hash = buff.name_hash or 0

        if should_dump then
            console.print(string.format("[CoA Debug] buff name='%s'  hash=%s  stacks=%s", 
                buff_name, tostring(name_hash), tostring(buff.stacks or 0)))
        end

        -- Primary check: exact hash 2506505
        if name_hash == coa_passive_buff_id then
            console.print(string.format("[CoA Debug] *** EXACT MATCH on 2506505 *** name='%s'  hash=%s", buff_name, tostring(name_hash)))
            found_match = true
        end

        -- Stricter string fallback
        local lower_name = string.lower(buff_name)
        local is_coa_passive_name = lower_name:find("call_of_the_ancients_passive", 1, true) or
                                    lower_name:find("calloftheancients_passive", 1, true) or
                                    (lower_name:find("call", 1, true) and lower_name:find("ancient", 1, true) and lower_name:find("passive", 1, true))

        if is_coa_passive_name then
            console.print(string.format("[CoA Debug] *** STRING MATCH *** name='%s'  hash=%s", buff_name, tostring(name_hash)))
            found_match = true
        end
    end

    if should_dump and #buffs > 0 then
        console.print(string.format("[CoA Debug] --- finished scanning %d buffs ---", #buffs))
    end

    return found_match
end

local function logics()
    local menu_boolean = menu_elements_call_of_the_anc.main_boolean:get()
    local is_logic_allowed = my_utility.is_spell_allowed(
        menu_boolean,
        next_time_allowed_cast,
        spell_id_ancient
    )
    if not is_logic_allowed then
        return false
    end

    -- ============================================
    -- TEMPORARY: Buff detection for call_of_the_ancients_passive is DISABLED.
    -- The ID 2506505 (and string fallbacks) were causing false positives / blocking good casts.
    -- We are currently relying on:
    --   - 5s summon timer (main.lua)
    --   - 75s hard floor
    --   - Sticky engagement flag
    --   - 300s internal throttle
    --   - Disengage logic
    -- ============================================
    -- The has_call_of_the_ancients_buff() function and debug printing are still available
    -- if you want to investigate the correct buff hash later (enable the Debug checkbox).
    local USE_COA_BUFF_DETECTION = false   -- <-- Flip this to true later when we have the correct hash

    if USE_COA_BUFF_DETECTION then
        local current_time = get_time_since_inject()
        local recently_cast = next_time_allowed_cast > current_time
        if recently_cast and has_call_of_the_ancients_buff() then
            console.print("[CoA Spell] Blocking cast because has_call_of_the_ancients_buff() returned true")
            return false
        end
    end

    local player_pos = get_player_position()
    local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 8.0, 8.0, false)
    local units = area_data.n_hits
    local elite_units, champion_units, boss_units = my_utility.should_pop_cds()

    local filter_mode = menu_elements_call_of_the_anc.filter_mode:get()
    local min_targets = menu_elements_call_of_the_anc.min_max_targets:get()

    local should_cast = false

    if filter_mode == 0 then
        -- No filter
        if units >= min_targets or elite_units >= 1 or boss_units >= 1 then
            should_cast = true
        end
    elseif filter_mode == 1 then
        -- Elites & Bosses Only (recommended)
        -- This is the main way to avoid casting on lone/weak "rare" mobs.
        -- Combine with "Min Enemies Around" = 2 or 3 for best results.
        local qualifying = elite_units + champion_units + boss_units
        should_cast = qualifying >= min_targets
    elseif filter_mode == 2 then
        -- Boss Only
        -- For pure boss fights we are lenient: any boss within the decision range (8yd) is enough.
        -- This helps CoA actually fire on bosses even if you're not stacked directly on them.
        -- (min_targets is mostly respected for multi-boss situations; set to 1 for reliability)
        should_cast = boss_units >= 1
    end

    if should_cast then
        if cast_spell.self(spell_id_ancient, 0.0) then
            local current_time = get_time_since_inject()
            next_time_allowed_cast = current_time + 300.0   -- Very strong hard throttle (5 minutes). This is the ultimate backstop against multiple casts on the same elites even if main.lua's flag resets early. Main.lua's logic should prevent most cases, but this protects against any leaks.
            console.print("Casted Call of the Ancients")
            return true
        end
    end

    return false
end

-- Reset the internal throttle.
-- This should ONLY be called by main.lua for a truly new engagement (full disengage or very long time).
-- Do not call this during an active elite pack or boss fight, as it removes the strong 300s protection.
local function reset()
    next_time_allowed_cast = 0.0
end

return {
    menu = menu,
    logics = logics,
    reset = reset,
    has_ancients_buff = has_call_of_the_ancients_buff,
    coa_passive_buff_id = coa_passive_buff_id,
    menu_elements = menu_elements_call_of_the_anc,   -- exposed so main.lua can read the debug checkbox
}