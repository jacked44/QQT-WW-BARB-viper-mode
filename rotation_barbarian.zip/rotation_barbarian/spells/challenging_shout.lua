local my_utility = require("my_utility/my_utility")

local menu_elements_challenging_shout_base = 
{
    tree_tab              = tree_node:new(1),
    main_boolean          = checkbox:new(true, get_hash(my_utility.plugin_label .. "main_boolean_challenging_shout_base")),
    filter_mode           = combo_box:new(0, get_hash(my_utility.plugin_label .. "challenging_shout_base_filter_mode")),
    min_max_targets       = slider_int:new(0, 30, 5, get_hash(my_utility.plugin_label .. "min_max_number_of_targets_for_challenging_shout_base")),
    use_off_cooldown      = checkbox:new(false, get_hash(my_utility.plugin_label .. "challenging_shout_use_off_cooldown"))
}

local function menu()
    
    if menu_elements_challenging_shout_base.tree_tab:push("Challenging Shout") then
        menu_elements_challenging_shout_base.main_boolean:render("Enable Spell", "")

        if menu_elements_challenging_shout_base.main_boolean:get() then
            local dropbox_options = {"No filter", "Elite & Boss Only", "Boss Only"}
            menu_elements_challenging_shout_base.filter_mode:render("Filter Modes", dropbox_options, "")
            menu_elements_challenging_shout_base.min_max_targets:render("Min Enemies Around", "Amount of targets to cast the spell")
            menu_elements_challenging_shout_base.use_off_cooldown:render("Use Off Cooldown", "Cast Challenging Shout constantly as soon as it's off cooldown (recommended for tanky builds)")
        end


        menu_elements_challenging_shout_base.tree_tab:pop()
    end
end
local next_time_allowed_cast = 0.0;
local spell_id_challenging_shout = 375484;

local function logics()

    local menu_boolean = menu_elements_challenging_shout_base.main_boolean:get();
    local is_logic_allowed = my_utility.is_spell_allowed(
                menu_boolean, 
                next_time_allowed_cast, 
                spell_id_challenging_shout);

    if not is_logic_allowed then
        return false
    end

    local use_off_cooldown = menu_elements_challenging_shout_base.use_off_cooldown:get()

    -- If "Use Off Cooldown" is enabled, cast as soon as the spell is ready (ignores buff + enemy count)
    if use_off_cooldown then
        if cast_spell.self(spell_id_challenging_shout, 0.000) then
            local current_time = get_time_since_inject()
            next_time_allowed_cast = current_time + 3.0
            console.print("Casted Challenging Shout (Off Cooldown mode)")
            return true
        end
        return false
    end

    -- === Normal Smart Mode: Only cast when the buff has worn off ===
    local player = get_local_player()
    if player then
        local buffs = player:get_buffs() or {}
        local challenging_buff_found = false
        for _, buff in ipairs(buffs) do
            local buff_name = ""
            if type(buff.name) == "function" then
                buff_name = buff:name() or ""
            end
            local lower_name = string.lower(buff_name)

            -- More robust matching for Challenging Shout buff (handles different internal names)
            if string.find(lower_name, "challeng") or 
               (string.find(lower_name, "shout") and string.find(lower_name, "threat")) or
               string.find(lower_name, "challenging_shout") then
                challenging_buff_found = true
                local remaining = 0
                if type(buff.get_remaining_time) == "function" then
                    remaining = buff:get_remaining_time() or 0
                end
                -- Don't cast if buff still has more than 3 seconds left
                if remaining > 3.0 then
                    return false
                end
            end
        end

        -- If we saw a shout buff but it wasn't the challenging one with time left, still be careful
        -- (extra safety to avoid spamming when off cooldown box is unchecked)
    end

    local filter_mode = menu_elements_challenging_shout_base.filter_mode:get()
    local player_pos = get_player_position()
    local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 5.50, 5.50, false)
    local units = area_data.n_hits
    local elite_units, champion_units, boss_units = my_utility.should_pop_cds()

    local min_targets = menu_elements_challenging_shout_base.min_max_targets:get()

    local should_cast = false
    if filter_mode == 0 then
        -- No filter: cast when enough enemies are around (respects your slider)
        should_cast = units >= min_targets
    elseif filter_mode == 1 then
        -- Elite & Boss Only (includes champions)
        -- Now properly respects the "Min Enemies Around" slider instead of hardcoding >= 1
        local qualifying = elite_units + champion_units + boss_units
        should_cast = qualifying >= min_targets
    elseif filter_mode == 2 then
        -- Boss Only
        -- Respects the slider (set it to 1 if you want it on any boss)
        should_cast = boss_units >= min_targets
    end

    if should_cast then
        if cast_spell.self(spell_id_challenging_shout, 0.000) then
            local current_time = get_time_since_inject()
            -- Stronger safety timer in normal (non off-cooldown) mode to prevent feeling like it casts off cooldown
            next_time_allowed_cast = current_time + 14.0
            console.print("Casted Challenging Shout (buff expired or low)")
            return true
        end
    end

    return false
end

return 
{
    menu = menu,
    logics = logics,   
}