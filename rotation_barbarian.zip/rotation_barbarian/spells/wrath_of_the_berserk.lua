local my_utility = require("my_utility/my_utility")

local menu_elements_wrath_of_berk_base=
{
    tree_tab              = tree_node:new(1),
    main_boolean          = checkbox:new(true, get_hash(my_utility.plugin_label .. "main_boolean_wrath_of_berk_base")),
    filter_mode           = combo_box:new(0, get_hash(my_utility.plugin_label .. "wrath_of_berk_base_filter_mode")),
    min_max_targets       = slider_int:new(0, 30, 5, get_hash(my_utility.plugin_label .. "min_max_number_of_targets_for_wrath_base"))
}

local function menu()

    if menu_elements_wrath_of_berk_base.tree_tab:push("Wrath Of The Berserk") then
        menu_elements_wrath_of_berk_base.main_boolean:render("Enable Spell", "")



        if menu_elements_wrath_of_berk_base.main_boolean:get() then
            local dropbox_options = {"No filter", "Elite & Boss Only", "Boss Only"}
            menu_elements_wrath_of_berk_base.filter_mode:render("Filter Modes", dropbox_options, "")
            menu_elements_wrath_of_berk_base.min_max_targets:render("Min Enemies Around", "Amount of targets to cast the spell")
        end

        menu_elements_wrath_of_berk_base.tree_tab:pop()
    end
end

local next_time_allowed_cast = 0.0;
local spell_id_wrath = 211871;


local function logics()

    local menu_boolean = menu_elements_wrath_of_berk_base.main_boolean:get();
    local is_logic_allowed = my_utility.is_spell_allowed(
                menu_boolean,
                next_time_allowed_cast,
                spell_id_wrath);

    if not is_logic_allowed then
    return false;
    end;

    local filter_mode = menu_elements_wrath_of_berk_base.filter_mode:get()
    local player_pos = get_player_position()
    local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 5.0, 5.0, false)
    local units = area_data.n_hits
    local elite_units, champion_units, boss_units = my_utility.should_pop_cds()

    -- More reliable boss detection (should_pop_cds only checks 8yd, which can miss bosses)
    -- Widen to ~18yd to match main adaptive targeting range so boss priority is consistent whether called from adaptive or directly.
    local has_boss = boss_units >= 1
    if not has_boss then
        for _, e in ipairs(actors_manager.get_enemy_npcs()) do
            if e:is_boss() and player_pos:dist_to(e:get_position()) < 18.0 then
                has_boss = true
                break
            end
        end
    end

    local min_targets = menu_elements_wrath_of_berk_base.min_max_targets:get()

    local should_cast = false
    if has_boss then
        -- ALWAYS cast Wrath on bosses (Pit or open world). This is a major DPS buff; never save it when a boss is present.
        should_cast = true
    elseif filter_mode == 0 then
        should_cast = units >= min_targets
    elseif filter_mode == 1 then
        -- Elite & Boss Only - be a bit smarter for long cooldown
        local elite_count = elite_units + champion_units
        should_cast = elite_count >= 2   -- "a couple of elites"
    elseif filter_mode == 2 then
        -- Boss Only: already handled by the has_boss gate above (we do want it on bosses)
        should_cast = false
    end

    if should_cast then
        if cast_spell.self(spell_id_wrath, 0.0) then
            local current_time = get_time_since_inject()
            next_time_allowed_cast = current_time + 25.0  -- safety cooldown (real CD is ~80s)
            console.print("Casted Wrath of the Berserk")
            return true
        else
            if has_boss then
                console.print("[Wrath] Tried to cast on boss but cast_spell.self failed (ready? fury? on CD?)")
            end
        end
    elseif has_boss then
        -- This should no longer happen after boss-priority fix, but kept as safety diagnostic
        console.print("[Wrath] Boss detected but should_cast=false (unexpected - please report)")
    end

    return false
end

return
{
    menu = menu,
    logics = logics,
}