local my_utility = require("my_utility/my_utility")

local menu_elements_rallying_cry_base = 
{
    tree_tab              = tree_node:new(1),
    main_boolean          = checkbox:new(true, get_hash(my_utility.plugin_label .. "main_boolean_unstable_rally_base")),
    filter_mode           = combo_box:new(0, get_hash(my_utility.plugin_label .. "unstable_rally_base_filter_mode")),
    min_max_targets       = slider_int:new(0, 30, 5, get_hash(my_utility.plugin_label .. "min_max_number_of_targets_for_cast_raly_base")),
    use_fixed_interval    = checkbox:new(false, get_hash(my_utility.plugin_label .. "rallying_cry_fixed_interval_7s")),
    encounter_7s_mode     = checkbox:new(false, get_hash(my_utility.plugin_label .. "rallying_cry_encounter_then_7s"))
}

local function menu()
    
    if menu_elements_rallying_cry_base.tree_tab:push("Rallying Cry") then
        menu_elements_rallying_cry_base.main_boolean:render("Enable Spell", "")

        if menu_elements_rallying_cry_base.main_boolean:get() then
            local dropbox_options = {"No filter", "Elite & Boss Only", "Boss Only"}
            menu_elements_rallying_cry_base.filter_mode:render("Filter Modes", dropbox_options, "")
        end

        if menu_elements_rallying_cry_base.main_boolean:get() then
            menu_elements_rallying_cry_base.min_max_targets:render("Min Enemies Around", "Amount of targets to cast the spell")
            menu_elements_rallying_cry_base.use_fixed_interval:render("Cast Every 7 Seconds", "Ignore buff timer and cast Rallying Cry on a fixed 7 second interval")
            menu_elements_rallying_cry_base.encounter_7s_mode:render("Encounter + Every 7s", "Cast once on first elite/boss, then every 7 seconds while in the encounter")
        end

        menu_elements_rallying_cry_base.tree_tab:pop()
    end
end

local next_time_allowed_cast = 0.0;
local spell_id_rally_cry = 211938;

-- Variables for "Encounter + Every 7s" mode
local last_rally_cast_time = 0.0
local has_cast_on_priority_encounter = false
local last_priority_target_seen = 0.0


local function logics()

    local menu_boolean = menu_elements_rallying_cry_base.main_boolean:get();
    local is_logic_allowed = my_utility.is_spell_allowed(
                menu_boolean, 
                next_time_allowed_cast, 
                spell_id_rally_cry);

    if not is_logic_allowed then
        return false
    end

    local current_time = get_time_since_inject()
    local use_encounter_7s = menu_elements_rallying_cry_base.encounter_7s_mode:get()

    if use_encounter_7s then
        -- === Encounter Mode: One cast on elites + then normal buff-wear-off upkeep ===
        local player_pos = get_player_position()
        local enemies = actors_manager.get_enemy_npcs() or {}
        local has_priority_nearby = false
        local current_units = 0

        -- Count enemies and detect elites/bosses
        local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 12.0, 12.0, false)
        current_units = area_data.n_hits

        for _, enemy in ipairs(enemies) do
            if enemy:is_elite() or enemy:is_boss() or enemy:is_champion() then
                if player_pos:dist_to(enemy:get_position()) < 18.0 then
                    has_priority_nearby = true
                    last_priority_target_seen = current_time
                    break
                end
            end
        end

        -- Reset the "first cast" flag after being away from elites/bosses for a while
        if current_time - last_priority_target_seen > 20.0 then
            has_cast_on_priority_encounter = false
        end

        local min_targets = menu_elements_rallying_cry_base.min_max_targets:get()

        -- First cast on elites/bosses (bypass buff check - this is the "once on elites" part)
        if has_priority_nearby and not has_cast_on_priority_encounter then
            if cast_spell.self(spell_id_rally_cry, 0.000) then
                last_rally_cast_time = current_time
                next_time_allowed_cast = current_time + 4.0
                has_cast_on_priority_encounter = true
                console.print("Casted Rallying Cry (First cast on elites/bosses)")
                return true
            end
            return false
        end

        -- After the first cast on elites, fall through to normal smart logic below
        -- (buff wear-off + slider). We do NOT return here so the normal checks run.
    end

    local use_fixed_interval = menu_elements_rallying_cry_base.use_fixed_interval:get()

    -- Fixed 7-second interval mode (simple version)
    if use_fixed_interval then
        local player_pos = get_player_position()
        local time_since_last = current_time - last_rally_cast_time
        if time_since_last >= 7.0 then
            -- Still respect the Min Enemies Around slider
            local min_targets = menu_elements_rallying_cry_base.min_max_targets:get()
            local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 12.0, 12.0, false)
            local current_units = area_data.n_hits

            if current_units >= min_targets then
                if cast_spell.self(spell_id_rally_cry, 0.000) then
                    last_rally_cast_time = current_time
                    next_time_allowed_cast = current_time + 7.0
                    console.print("Casted Rallying Cry (Fixed 7s interval)")
                    return true
                end
            end
        end
        return false
    end

    -- === Smart Buff Check: Only cast when the Rallying Cry buff has worn off ===
    local player = get_local_player()
    if player then
        local buffs = player:get_buffs() or {}
        local has_active_rally = false

        for _, buff in ipairs(buffs) do
            local buff_name = ""
            if type(buff.name) == "function" then
                buff_name = buff:name() or ""
            end
            local lower_name = string.lower(buff_name)

            -- More robust detection for Rallying Cry
            if string.find(lower_name, "rally") or 
               string.find(lower_name, "barbarian_rally") or
               string.find(lower_name, "rallyingcry") then

                local remaining = 0
                if type(buff.get_remaining_time) == "function" then
                    remaining = buff:get_remaining_time() or 0
                end

                -- Only block if the buff still has a meaningful amount of time left
                if remaining > 0.5 then
                    has_active_rally = true
                    break
                end
            end
        end

        if has_active_rally then
            return false
        end
    end

    local filter_mode = menu_elements_rallying_cry_base.filter_mode:get()
    local player_pos = get_player_position()

    -- Use a larger radius for "enemies around" so the Min Enemies slider actually feels useful
    local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 10.0, 10.0, false)
    local units = area_data.n_hits

    local elite_units, champion_units, boss_units = my_utility.should_pop_cds()
    local min_targets = menu_elements_rallying_cry_base.min_max_targets:get()

    local should_cast = false
    if filter_mode == 0 then
        -- No filter: respect the "Min Enemies Around" slider
        should_cast = units >= min_targets
    elseif filter_mode == 1 then
        -- Elite & Boss Only (includes champions)
        should_cast = elite_units >= 1 or champion_units >= 1 or boss_units >= 1
    elseif filter_mode == 2 then
        -- Boss Only
        should_cast = boss_units >= 1
    end

    if should_cast then
        if cast_spell.self(spell_id_rally_cry, 0.000) then
            local current_time = get_time_since_inject()
            next_time_allowed_cast = current_time + 4.0   -- small safety; main protection is the buff check
            console.print("Casted Rallying Cry (buff expired)")
            return true
        end
    end

    return false
end

return 
{
    menu = menu,
    logics = logics,   
}