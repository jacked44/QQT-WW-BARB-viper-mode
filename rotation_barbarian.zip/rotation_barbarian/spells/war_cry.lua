local my_utility = require("my_utility/my_utility")

local menu_elements_war_cry_base = 
{
    tree_tab              = tree_node:new(1),
    main_boolean          = checkbox:new(true, get_hash(my_utility.plugin_label .. "main_boolean_war_cry_base")),
    filter_mode           = combo_box:new(0, get_hash(my_utility.plugin_label .. "war_cry_base_filter_mode")),
    min_max_targets       = slider_int:new(0, 30, 5, get_hash(my_utility.plugin_label .. "min_max_number_of_targets_for_war_cry_base"))
}

local function menu()
    
    if menu_elements_war_cry_base.tree_tab:push("War Cry") then
        menu_elements_war_cry_base.main_boolean:render("Enable Spell", "")

        if menu_elements_war_cry_base.main_boolean:get() then
            local dropbox_options = {"No filter", "Elite & Boss Only", "Boss Only"}
            menu_elements_war_cry_base.filter_mode:render("Filter Modes", dropbox_options, "")
        end

        if menu_elements_war_cry_base.main_boolean:get() then
            menu_elements_war_cry_base.min_max_targets:render("Min Enemies Around", "Amount of targets to cast the spell")
        end

        menu_elements_war_cry_base.tree_tab:pop()
    end
end

local next_time_allowed_cast = 0.0;
local spell_id_war_cry = 184600;


local function logics()

    local menu_boolean = menu_elements_war_cry_base.main_boolean:get();
    local is_logic_allowed = my_utility.is_spell_allowed(
                menu_boolean, 
                next_time_allowed_cast, 
                spell_id_war_cry);

    if not is_logic_allowed then
        return false
    end

    -- === Smart Buff Check: Only cast when the buff has worn off (or is about to) ===
    local player = get_local_player()
    if player then
        local buffs = player:get_buffs() or {}
        for _, buff in ipairs(buffs) do
            local buff_name = ""
            if type(buff.name) == "function" then
                buff_name = buff:name() or ""
            end
            local lower_name = string.lower(buff_name)

            -- More robust matching for War Cry buff (handles different internal names like WarCry, Barbarian_WarCry, etc.)
            if string.find(lower_name, "war") and (string.find(lower_name, "cry") or string.find(lower_name, "warcry")) or
               string.find(lower_name, "barbarian_war") then
                local remaining = 0
                if type(buff.get_remaining_time) == "function" then
                    remaining = buff:get_remaining_time() or 0
                end
                -- Don't cast if buff still has more than 3 seconds left
                if remaining > 3.0 then
                    return false
                end
            end
        end
    end

    local filter_mode = menu_elements_war_cry_base.filter_mode:get()
    local player_pos = get_player_position()
    local area_data = target_selector.get_most_hits_target_circular_area_light(player_pos, 5.00, 5.00, false)
    local units = area_data.n_hits
    local elite_units, champion_units, boss_units = my_utility.should_pop_cds()

    local min_targets = menu_elements_war_cry_base.min_max_targets:get()

    local should_cast = false
    if filter_mode == 0 then
        -- No filter: cast when enough enemies are around (respects your slider)
        should_cast = units >= min_targets
    elseif filter_mode == 1 then
        -- Elite & Boss Only (includes champions)
        -- War Cry is a key burst buff, so it fires on any elite/boss pack (the slider mainly controls "No filter" mode)
        should_cast = elite_units >= 1 or champion_units >= 1 or boss_units >= 1
    elseif filter_mode == 2 then
        -- Boss Only
        should_cast = boss_units >= 1
    end

    if should_cast then
        if cast_spell.self(spell_id_war_cry, 0.000) then
            local current_time = get_time_since_inject()
            -- Safety timer after cast. Lower than Challenging Shout because War Cry is a key damage/fury buff that benefits from more frequent use on elites via the burst combo.
            next_time_allowed_cast = current_time + 10.0
            console.print("Casted War Cry (buff expired or low)")
            return true
        end
    end

    return false
end

return
{
    menu = menu,
    logics = logics,   
}