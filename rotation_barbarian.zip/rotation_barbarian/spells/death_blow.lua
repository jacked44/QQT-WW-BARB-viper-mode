local my_utility = require("my_utility/my_utility")

local menu_elements_death_blow_base =
{
    tree_tab            = tree_node:new(1),
    main_boolean        = checkbox:new(true, get_hash(my_utility.plugin_label .. "death_blow_base_main_bool")),
    only_elites         = checkbox:new(true, get_hash(my_utility.plugin_label .. "death_blow_only_elites")),
    min_hp_percent      = slider_float:new(0.05, 0.60, 0.35, get_hash(my_utility.plugin_label .. "death_blow_min_hp")),
}

local function menu()
    
    if menu_elements_death_blow_base.tree_tab:push("Death Blow")then
        menu_elements_death_blow_base.main_boolean:render("Enable Spell", "")

        if menu_elements_death_blow_base.main_boolean:get() then
            menu_elements_death_blow_base.only_elites:render("Only on Elites/Bosses", "Only use as a finisher on priority targets")
            menu_elements_death_blow_base.min_hp_percent:render("Max Target HP %", "Only cast on targets below this HP percent")
        end
 
        menu_elements_death_blow_base.tree_tab:pop()
    end
end

local spell_id_death_blow = 323105;  -- Verify this ID in game if possible

local death_blow_spell_data = spell_data:new(
    2.0,                            -- radius
    1.5,                            -- range
    0.6,                            -- cast_delay
    0.5,                            -- projectile_speed
    true,                           -- has_collision
    spell_id_death_blow,            -- spell_id
    spell_geometry.rectangular,     -- geometry_type
    targeting_type.targeted         --targeting_type
)
local next_time_allowed_cast = 0.0;
local function logics(target)
    
    local menu_boolean = menu_elements_death_blow_base.main_boolean:get();
    local is_logic_allowed = my_utility.is_spell_allowed(
                menu_boolean, 
                next_time_allowed_cast, 
                spell_id_upheavel);

    if not is_logic_allowed then
        return false;
    end;

    if cast_spell.target(target, death_blow_spell_data, false) then

        local current_time = get_time_since_inject();
        next_time_allowed_cast = current_time + 0.2;

        console.print("Casted Death Blow");
        return true;
    end;
            
    return false;
end


return 
{
    menu = menu,
    logics = logics,   
}