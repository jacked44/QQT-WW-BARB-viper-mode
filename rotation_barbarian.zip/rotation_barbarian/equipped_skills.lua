-- equipped_skills.lua
-- Modern equipped skill detection for the Barbarian rotation (modeled after advanced Necro patterns).
-- This module allows the rotation to only consider skills the player actually has equipped.

local equipped_skills = {}

-- Complete Barbarian spell ID mapping (gathered from all spell files + common knowledge)
local SPELL_ID_MAP = {
    -- Generators / Basics
    [206504] = "lunging_strike",
    [200765] = "bash",
    [210919] = "frenzy",
    [210431] = "flay",

    -- Core Spenders
    [206435] = "whirl_wind",
    [213673] = "hammer_of_ancients",
    [202484] = "upheaval",
    [208000] = "double_swing",
    [214786] = "rend",

    -- Mobility
    [204662] = "charge",
    [196545] = "leap",
    [964631] = "steel_grasp",
    [199516] = "kick",

    -- Shouts
    [184600] = "war_cry",
    [211938] = "rallying_cry",
    [375484] = "challenging_shout",

    -- Defensives & Utility
    [512222] = "iron_skin",
    [186358] = "ground_stomp",

    -- Big Cooldowns / Ultimates
    [309802] = "call_of_the_ancients",
    [211871] = "wrath_of_the_berserk",
    [217175] = "iron_maelstrom",

    -- Finishers
    [215027] = "rupture",
    [323105] = "death_blow",
}

-- Reverse lookup
local MODULE_TO_ID = {}
for id, module in pairs(SPELL_ID_MAP) do
    MODULE_TO_ID[module] = id
end

local cache = {}
local last_refresh = 0
local REFRESH_INTERVAL = 1.5

local function refresh()
    local now = get_time_since_inject()
    if now - last_refresh < REFRESH_INTERVAL then
        return cache
    end

    cache = {}
    local ids = get_equipped_spell_ids() or {}

    for _, id in ipairs(ids) do
        if id > 1 then
            local module_name = SPELL_ID_MAP[id]
            if module_name then
                cache[module_name] = true
                cache[id] = true
            end
        end
    end

    last_refresh = now
    return cache
end

function equipped_skills.is_equipped(name_or_id)
    local c = refresh()
    return c[name_or_id] == true
end

function equipped_skills.get_equipped_modules()
    local c = refresh()
    local list = {}
    for module, _ in pairs(MODULE_TO_ID) do
        if c[module] then
            table.insert(list, module)
        end
    end
    return list
end

function equipped_skills.get_missing_modules()
    local c = refresh()
    local list = {}
    for module, _ in pairs(MODULE_TO_ID) do
        if not c[module] then
            table.insert(list, module)
        end
    end
    return list
end

function equipped_skills.get_spell_id(module_name)
    return MODULE_TO_ID[module_name]
end

function equipped_skills.force_refresh()
    last_refresh = 0
end

function equipped_skills.debug_print()
    local equipped = equipped_skills.get_equipped_modules()
    console.print("[Equipped Skills] " .. (#equipped > 0 and table.concat(equipped, ", ") or "None detected"))
end

-- ============================================
-- Advanced Build Detection (Universal Logic)
-- ============================================

function equipped_skills.detect_archetype()
    local c = refresh()

    local has_ww = c["whirl_wind"] == true
    local has_hota = c["hammer_of_ancients"] == true
    local has_lunging = c["lunging_strike"] == true
    local has_leap = c["leap"] == true
    local has_ancients = c["call_of_the_ancients"] == true
    local has_wrath = c["wrath_of_the_berserk"] == true
    local has_rend = c["rend"] == true
    local has_upheaval = c["upheaval"] == true

    local generator_count = 0
    if has_lunging then generator_count = generator_count + 1 end
    if c["bash"] then generator_count = generator_count + 1 end
    if c["frenzy"] then generator_count = generator_count + 1 end
    if c["flay"] then generator_count = generator_count + 1 end

    -- WW focused detection (especially meta with Lunging/Leap flexibility)
    if has_ww then
        if has_ancients and generator_count >= 1 then
            return "WW_Minion"   -- Strong Minion/Call of Ancients WW
        elseif has_hota then
            return "WW_HoTA_Hybrid"
        else
            return "WW_Pure"     -- Classic Dust Devil WW
        end
    end

    -- HoTA focused
    if has_hota then
        if has_ww then
            return "HoTA_WW_Hybrid"
        else
            return "HoTA_Pure"
        end
    end

    -- Fallbacks
    if generator_count >= 2 and has_leap then
        return "Mobility_Generator"  -- Basic or leveling style
    end

    return "Unknown"
end

function equipped_skills.has_mobility_options()
    local c = refresh()
    return c["lunging_strike"] or c["leap"] or c["charge"] or c["steel_grasp"]
end

-- Note: We keep build detection for future profile-aware logic,
-- but mobility (Leap/Lunging) is now purely "use whatever is equipped".

return equipped_skills